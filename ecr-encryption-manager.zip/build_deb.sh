#!/bin/bash
# ECR Encryption Manager v2.1 - Debian (.deb) Package Builder Script

set -e

echo "============================================================"
echo " Building ECR Encryption Manager v2.1 Debian Package (.deb)"
echo "============================================================"

# Ensure ecr-manager.jar exists, or build it
if [ ! -f "ecr-manager.jar" ]; then
    echo "ecr-manager.jar not found. Running compilation..."
    ./compile.sh
fi

PKG_DIR="build_deb/ecr-manager_2.1-1_all"

# Clean up previous build directory
rm -rf build_deb
mkdir -p "$PKG_DIR/DEBIAN"
mkdir -p "$PKG_DIR/usr/share/java"
mkdir -p "$PKG_DIR/usr/bin"

# 1. Copy the executable JAR
cp ecr-manager.jar "$PKG_DIR/usr/share/java/ecr-manager.jar"

# 2. Create executable wrapper in /usr/bin/ecr-manager
cat << 'EOF' > "$PKG_DIR/usr/bin/ecr-manager"
#!/bin/sh
exec java -jar /usr/share/java/ecr-manager.jar "$@"
EOF

chmod +x "$PKG_DIR/usr/bin/ecr-manager"

# 3. Create Debian control file
cat << 'EOF' > "$PKG_DIR/DEBIAN/control"
Package: ecr-manager
Version: 2.1-1
Section: utils
Priority: optional
Architecture: all
Maintainer: ECR Security Team <support@ecr.local>
Depends: default-jre | openjdk-17-jre | openjdk-21-jre | java-runtime
Description: ECR Encryption Manager v2.1
 High-security cryptographic file archive vault utility for AES-256-GCM container encryption and Ed25519 digital signatures.
EOF

# 4. Build .deb package using dpkg-deb or tar fallback
if command -v dpkg-deb >/dev/null 2>&1; then
    dpkg-deb --build "$PKG_DIR" ecr-manager_2.1-1_all.deb
    echo "============================================================"
    echo "✔ Debian package created successfully: ecr-manager_2.1-1_all.deb"
    echo ""
    echo "To install on Ubuntu / Debian / Linux Mint:"
    echo "   sudo dpkg -i ecr-manager_2.1-1_all.deb"
    echo "   # or"
    echo "   sudo apt install ./ecr-manager_2.1-1_all.deb"
    echo ""
    echo "To run anywhere from terminal:"
    echo "   ecr-manager"
    echo "============================================================"
else
    echo "⚠ dpkg-deb tool not found on this system, but package directory structure created at: $PKG_DIR"
    echo "You can build it on any Debian/Ubuntu system using: dpkg-deb --build $PKG_DIR ecr-manager_2.1-1_all.deb"
fi
