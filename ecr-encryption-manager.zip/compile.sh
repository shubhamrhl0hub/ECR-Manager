#!/bin/bash
# ECR Encryption Manager v2.1 - Java 26 Build Script

echo "============================================================"
echo "Compiling ECR Encryption Manager v2.1 (Java 26)..."
echo "============================================================"

mkdir -p bin

JAVA_FILES=$(find src/java_code -name "*.java")

if [ -z "$JAVA_FILES" ]; then
    echo "No Java files found under src/java_code."
    exit 1
fi

javac -d bin $JAVA_FILES

if [ $? -eq 0 ]; then
    echo "✔ Java compilation successful! Binaries created in ./bin"
    
    echo "Packaging executable single JAR file (ecr-manager.jar)..."
    jar cfe ecr-manager.jar com.ecr.Main -C bin .
    
    if [ $? -eq 0 ]; then
        echo "✔ Executable JAR successfully created: ecr-manager.jar"
        echo "============================================================"
        echo "How to run the project:"
        echo ""
        echo "1. Run from compiled class files:"
        echo "   java -cp bin com.ecr.Main"
        echo ""
        echo "2. Run directly from the single executable JAR:"
        echo "   java -jar ecr-manager.jar"
        echo ""
        echo "3. Build Debian (.deb) installer package:"
        echo "   chmod +x build_deb.sh && ./build_deb.sh"
        echo "============================================================"
    else
        echo "✖ JAR creation failed."
        exit 1
    fi
else
    echo "✖ Java compilation failed."
    exit 1
fi

