import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import AdmZip from 'adm-zip';

const app = express();
const PORT = 3000;

// Setup Multer for file uploads in memory
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 500 * 1024 * 1024 } });

app.use(express.json());

// --- SECURE CONFIGURATION SYSTEM ---
interface ECRConfig {
  chunkSizeBytes: number;
  kdfIterations: number;
  showProgress: boolean;
  enableDigitalSignatures: boolean;
  maxLogSizeMB: number;
  maxLogFiles: number;
  auditLogFilePath: string;
  minSupportedVersion: number;
  allowLegacyVersions: boolean;
}

const DEFAULT_CONFIG: ECRConfig = {
  chunkSizeBytes: 64 * 1024, // 64 KB
  kdfIterations: 210000,
  showProgress: true,
  enableDigitalSignatures: true,
  maxLogSizeMB: 5,
  maxLogFiles: 5,
  auditLogFilePath: 'ecr-audit.log',
  minSupportedVersion: 1,
  allowLegacyVersions: true
};

let activeConfig: ECRConfig = { ...DEFAULT_CONFIG };

// --- SECURE AUDIT LOG SYSTEM ---
const serverAuditLogs: string[] = [];
const MAX_IN_MEMORY_LOGS = 100;

function sanitizeLogDetail(detail: string): string {
  if (!detail) return '';
  return detail.replace(/(password|secret|key|token|auth)[=:]\s*\S+/gi, '$1=[REDACTED]');
}

function recordAuditLog(eventType: string, status: 'SUCCESS' | 'FAILED' | 'INFO', detail: string) {
  const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
  const safeDetail = sanitizeLogDetail(detail);
  const logEntry = `[${timestamp}] [${eventType.padEnd(18)}] [${status.padEnd(7)}] - ${safeDetail}`;

  console.log(logEntry);

  serverAuditLogs.push(logEntry);
  if (serverAuditLogs.length > MAX_IN_MEMORY_LOGS) {
    serverAuditLogs.shift();
  }

  // Persistent file write with safe error handling
  try {
    const logPath = path.resolve(process.cwd(), activeConfig.auditLogFilePath);
    
    // Check log file size for rotation
    if (fs.existsSync(logPath)) {
      const stats = fs.statSync(logPath);
      const maxBytes = activeConfig.maxLogSizeMB * 1024 * 1024;
      if (stats.size >= maxBytes) {
        rotateLogFiles(logPath, activeConfig.maxLogFiles);
      }
    }

    fs.appendFileSync(logPath, logEntry + '\n', 'utf-8');
  } catch (err: any) {
    console.warn('⚠ AUDIT LOG FILE ERROR:', err.message);
  }
}

function rotateLogFiles(mainLogPath: string, maxFiles: number) {
  try {
    const oldestPath = `${mainLogPath}.${maxFiles}`;
    if (fs.existsSync(oldestPath)) fs.unlinkSync(oldestPath);

    for (let i = maxFiles - 1; i >= 1; i--) {
      const src = `${mainLogPath}.${i}`;
      const dest = `${mainLogPath}.${i + 1}`;
      if (fs.existsSync(src)) fs.renameSync(src, dest);
    }

    const dest1 = `${mainLogPath}.1`;
    if (fs.existsSync(mainLogPath)) fs.renameSync(mainLogPath, dest1);
  } catch (err: any) {
    console.warn('⚠ LOG ROTATION ERROR:', err.message);
  }
}

// Initial system startup audit record
recordAuditLog('APP_STARTUP', 'SUCCESS', 'ECR Encryption Manager Express Server initialized with Secure Configuration.');

// --- BINARY ECR SPECIFICATION HELPERS ---
const MAGIC_HEADER = Buffer.from([0x45, 0x43, 0x52, 0x31]); // "ECR1"
const HEADER_FIXED_SIZE = 4 + 2 + 1 + 4 + 32 + 12 + 4; // 59 bytes

/**
 * Encrypt ZIP buffer to ECR binary buffer with optional digital signature
 */
function encryptZipToEcrBuffer(
  zipBuffer: Buffer,
  filename: string,
  passwordStr: string,
  iterations = activeConfig.kdfIterations,
  signingPrivateKeyBase64?: string,
  signerPublicKeyBase64?: string
): Buffer {
  const salt = crypto.randomBytes(32);
  const nonce = crypto.randomBytes(12);

  // Derive 256-bit key using PBKDF2-HMAC-SHA512
  const derivedKey = crypto.pbkdf2Sync(passwordStr, salt, iterations, 32, 'sha512');

  // Compute SHA-256 checksum of original ZIP
  const sha256Checksum = crypto.createHash('sha256').update(zipBuffer).digest('hex');

  let sigBase64: string | undefined;
  let pubKeyBase64: string | undefined;

  if (activeConfig.enableDigitalSignatures && signingPrivateKeyBase64 && signerPublicKeyBase64) {
    try {
      const privateKey = crypto.createPrivateKey({
        key: Buffer.from(signingPrivateKeyBase64, 'base64'),
        format: 'der',
        type: 'pkcs8'
      });
      const sigBuffer = crypto.sign(null, Buffer.from(sha256Checksum, 'utf-8'), privateKey);
      sigBase64 = sigBuffer.toString('base64');
      pubKeyBase64 = signerPublicKeyBase64;
    } catch (e) {
      console.warn('Node Ed25519 signing failed, embedding provided signature keys', e);
      pubKeyBase64 = signerPublicKeyBase64;
    }
  }

  // Prepare metadata payload
  const metadataObj: any = {
    file: filename,
    timestamp: Math.floor(Date.now() / 1000),
    size: zipBuffer.length,
    sha256: sha256Checksum
  };
  if (sigBase64) metadataObj.sig = sigBase64;
  if (pubKeyBase64) metadataObj.pubKey = pubKeyBase64;

  const metadataBytes = Buffer.from(JSON.stringify(metadataObj), 'utf-8');

  // Build Fixed Header (59 bytes)
  const header = Buffer.alloc(HEADER_FIXED_SIZE);
  let offset = 0;
  MAGIC_HEADER.copy(header, offset); offset += 4;
  header.writeUInt16BE(1, offset); offset += 2; // Version 1
  header.writeUInt8(1, offset); offset += 1; // KDF 1 = PBKDF2-HMAC-SHA512
  header.writeUInt32BE(iterations, offset); offset += 4;
  salt.copy(header, offset); offset += 32;
  nonce.copy(header, offset); offset += 12;
  header.writeUInt32BE(metadataBytes.length, offset);

  // Encrypt with AES-256-GCM
  const cipher = crypto.createCipheriv('aes-256-gcm', derivedKey, nonce);
  cipher.setAAD(header); // Bind header into authentication tag

  const ciphertextPart = cipher.update(zipBuffer);
  const finalPart = cipher.final();
  const authTag = cipher.getAuthTag(); // 16 bytes tag

  const fullCiphertext = Buffer.concat([ciphertextPart, finalPart, authTag]);

  // Zeroize sensitive key buffer
  derivedKey.fill(0);

  // Combine full ECR File: Header + Metadata + CiphertextWithTag
  return Buffer.concat([header, metadataBytes, fullCiphertext]);
}

/**
 * Decrypt ECR buffer to original ZIP buffer
 */
function decryptEcrBuffer(ecrBuffer: Buffer, passwordStr: string): { zipBuffer: Buffer; metadata: any; header: any } {
  if (ecrBuffer.length < HEADER_FIXED_SIZE) {
    recordAuditLog('VALIDATION_FAILURE', 'FAILED', 'Uploaded ECR buffer smaller than fixed header size.');
    throw new Error('«Invalid, corrupted, tampered, or unsupported ECR file.»');
  }

  const magic = ecrBuffer.subarray(0, 4);
  if (!magic.equals(MAGIC_HEADER)) {
    recordAuditLog('VALIDATION_FAILURE', 'FAILED', 'Magic header mismatch in uploaded ECR file.');
    throw new Error('«Invalid, corrupted, tampered, or unsupported ECR file.»');
  }

  const version = ecrBuffer.readUInt16BE(4);
  if (version !== 1) {
    recordAuditLog('VALIDATION_FAILURE', 'FAILED', `Unsupported ECR format version ${version}`);
    throw new Error('«Invalid, corrupted, tampered, or unsupported ECR file.»');
  }

  const kdfAlg = ecrBuffer.readUInt8(6);
  const iterations = ecrBuffer.readUInt32BE(7);
  const salt = ecrBuffer.subarray(11, 43);
  const nonce = ecrBuffer.subarray(43, 55);
  const metadataLen = ecrBuffer.readUInt32BE(55);

  if (ecrBuffer.length < HEADER_FIXED_SIZE + metadataLen + 16) {
    recordAuditLog('VALIDATION_FAILURE', 'FAILED', 'Truncated ECR file layout.');
    throw new Error('«Invalid, corrupted, tampered, or unsupported ECR file.»');
  }

  const headerBytes = ecrBuffer.subarray(0, HEADER_FIXED_SIZE);
  const metadataBytes = ecrBuffer.subarray(HEADER_FIXED_SIZE, HEADER_FIXED_SIZE + metadataLen);
  const ciphertextWithTag = ecrBuffer.subarray(HEADER_FIXED_SIZE + metadataLen);

  if (ciphertextWithTag.length < 16) {
    recordAuditLog('VALIDATION_FAILURE', 'FAILED', 'Ciphertext payload too short for auth tag.');
    throw new Error('«Invalid, corrupted, tampered, or unsupported ECR file.»');
  }

  let metadata: any;
  try {
    metadata = JSON.parse(metadataBytes.toString('utf-8'));
  } catch {
    recordAuditLog('VALIDATION_FAILURE', 'FAILED', 'Corrupted JSON metadata block.');
    throw new Error('«Invalid, corrupted, tampered, or unsupported ECR file.»');
  }

  // Verify optional Digital Signature before decryption
  if (metadata.sig && metadata.pubKey) {
    try {
      const publicKey = crypto.createPublicKey({
        key: Buffer.from(metadata.pubKey, 'base64'),
        format: 'der',
        type: 'spki'
      });
      const verified = crypto.verify(null, Buffer.from(metadata.sha256, 'utf-8'), publicKey, Buffer.from(metadata.sig, 'base64'));
      if (!verified) {
        recordAuditLog('SIGNATURE_VERIFY', 'FAILED', `Ed25519 signature verification failed for file ${metadata.file}`);
        throw new Error('Digital Signature Verification Failed: Authenticity of file source cannot be confirmed.');
      }
      recordAuditLog('SIGNATURE_VERIFY', 'SUCCESS', `Ed25519 signature verified authentic for file ${metadata.file}`);
    } catch (sigErr: any) {
      if (sigErr.message.includes('Digital Signature Verification Failed')) throw sigErr;
    }
  }

  // Derive key
  const derivedKey = crypto.pbkdf2Sync(passwordStr, salt, iterations, 32, 'sha512');

  const authTag = ciphertextWithTag.subarray(ciphertextWithTag.length - 16);
  const ciphertext = ciphertextWithTag.subarray(0, ciphertextWithTag.length - 16);

  try {
    const decipher = crypto.createDecipheriv('aes-256-gcm', derivedKey, nonce);
    decipher.setAAD(headerBytes);
    decipher.setAuthTag(authTag);

    const decryptedPart = decipher.update(ciphertext);
    const finalPart = decipher.final();
    const zipBuffer = Buffer.concat([decryptedPart, finalPart]);

    derivedKey.fill(0);

    // Verify SHA-256 payload integrity
    const computedHash = crypto.createHash('sha256').update(zipBuffer).digest('hex');
    if (computedHash.toLowerCase() !== (metadata.sha256 || '').toLowerCase()) {
      recordAuditLog('INTEGRITY_CHECK', 'FAILED', `SHA-256 mismatch for file ${metadata.file}`);
      throw new Error('«Invalid, corrupted, tampered, or unsupported ECR file.»');
    }

    return {
      zipBuffer,
      metadata,
      header: {
        version,
        kdfAlg,
        iterations,
        saltHex: salt.toString('hex'),
        nonceHex: nonce.toString('hex')
      }
    };
  } catch (err: any) {
    derivedKey.fill(0);
    recordAuditLog('DECRYPT_FAILURE', 'FAILED', `Decryption failed or auth tag rejected: ${err.message}`);
    throw new Error('«Invalid, corrupted, tampered, or unsupported ECR file.»');
  }
}

// --- API ROUTES ---

// Config Management APIs
app.get('/api/config', (req, res) => {
  return res.json({
    config: activeConfig,
    bounds: {
      chunkSizeBytes: { min: 4096, max: 10485760, default: 65536 },
      kdfIterations: { min: 100000, max: 10000000, default: 210000 },
      maxLogSizeMB: { min: 1, max: 100, default: 5 },
      maxLogFiles: { min: 1, max: 20, default: 5 }
    }
  });
});

app.post('/api/config', (req, res) => {
  try {
    const { chunkSizeBytes, kdfIterations, showProgress, enableDigitalSignatures, maxLogSizeMB, maxLogFiles } = req.body;

    if (typeof chunkSizeBytes === 'number') {
      if (chunkSizeBytes >= 4096 && chunkSizeBytes <= 10485760) activeConfig.chunkSizeBytes = chunkSizeBytes;
      else recordAuditLog('CONFIG_WARN', 'FAILED', `chunkSizeBytes ${chunkSizeBytes} out of bounds.`);
    }

    if (typeof kdfIterations === 'number') {
      if (kdfIterations >= 100000 && kdfIterations <= 10000000) activeConfig.kdfIterations = kdfIterations;
      else recordAuditLog('CONFIG_WARN', 'FAILED', `kdfIterations ${kdfIterations} out of bounds.`);
    }

    if (typeof showProgress === 'boolean') activeConfig.showProgress = showProgress;
    if (typeof enableDigitalSignatures === 'boolean') activeConfig.enableDigitalSignatures = enableDigitalSignatures;

    if (typeof maxLogSizeMB === 'number' && maxLogSizeMB >= 1 && maxLogSizeMB <= 100) {
      activeConfig.maxLogSizeMB = maxLogSizeMB;
    }
    if (typeof maxLogFiles === 'number' && maxLogFiles >= 1 && maxLogFiles <= 20) {
      activeConfig.maxLogFiles = maxLogFiles;
    }

    recordAuditLog('CONFIG_UPDATE', 'SUCCESS', `Updated configuration parameters: Chunk=${activeConfig.chunkSizeBytes}B, Iterations=${activeConfig.kdfIterations}`);
    return res.json({ success: true, config: activeConfig });
  } catch (err: any) {
    recordAuditLog('CONFIG_UPDATE_ERR', 'FAILED', err.message);
    return res.status(400).json({ error: 'Failed to update configuration: ' + err.message });
  }
});

// Audit Log Retrieval API
app.get('/api/audit-logs', (req, res) => {
  return res.json({ logs: serverAuditLogs });
});

// Key Pair API
app.get('/api/generate-keypair', (req, res) => {
  try {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519', {
      publicKeyEncoding: { type: 'spki', format: 'der' },
      privateKeyEncoding: { type: 'pkcs8', format: 'der' }
    });
    return res.json({
      publicKeyBase64: publicKey.toString('base64'),
      privateKeyBase64: privateKey.toString('base64')
    });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// 1. Encrypt API
app.post('/api/encrypt', upload.single('file'), (req, res) => {
  try {
    const file = req.file;
    const password = req.body.password;
    const iterations = parseInt(req.body.iterations || String(activeConfig.kdfIterations), 10);
    const signPrivateKey = req.body.signPrivateKey;
    const signPublicKey = req.body.signPublicKey;

    if (!file || !password) {
      recordAuditLog('ENCRYPT_FAILURE', 'FAILED', 'Missing file or password parameter.');
      return res.status(400).json({ error: 'Missing file or password' });
    }

    const filename = file.originalname || 'archive.zip';
    recordAuditLog('ENCRYPT_START', 'INFO', `Encrypting ZIP file '${filename}' (${file.buffer.length} bytes)...`);

    const ecrBuf = encryptZipToEcrBuffer(file.buffer, filename, password, iterations, signPrivateKey, signPublicKey);

    const outName = filename.replace(/\.zip$/i, '') + '.ecr';
    recordAuditLog('ENCRYPT_SUCCESS', 'SUCCESS', `Successfully encrypted '${filename}' -> '${outName}' (${ecrBuf.length} bytes).`);

    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${outName}"`);
    return res.send(ecrBuf);
  } catch (err: any) {
    recordAuditLog('ENCRYPT_FAILURE', 'FAILED', err.message || 'Encryption failed');
    return res.status(500).json({ error: err.message || 'Encryption failed' });
  }
});

// 2. Decrypt API
app.post('/api/decrypt', upload.single('file'), (req, res) => {
  try {
    const file = req.file;
    const password = req.body.password;

    if (!file || !password) {
      recordAuditLog('DECRYPT_FAILURE', 'FAILED', 'Missing file or password parameter.');
      return res.status(400).json({ error: 'Missing file or password' });
    }

    recordAuditLog('DECRYPT_START', 'INFO', `Decrypting ECR file '${file.originalname}'...`);

    const { zipBuffer, metadata } = decryptEcrBuffer(file.buffer, password);

    const outName = metadata.file || 'decrypted.zip';
    recordAuditLog('DECRYPT_SUCCESS', 'SUCCESS', `Successfully decrypted '${file.originalname}' -> '${outName}' (${zipBuffer.length} bytes).`);

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${outName}"`);
    return res.send(zipBuffer);
  } catch (err: any) {
    recordAuditLog('DECRYPT_FAILURE', 'FAILED', err.message);
    return res.status(400).json({ error: err.message || '«Invalid, corrupted, tampered, or unsupported ECR file.»' });
  }
});

// 3. Verify API
app.post('/api/verify', upload.single('file'), (req, res) => {
  try {
    const file = req.file;
    if (!file) return res.status(400).json({ error: 'No file uploaded' });

    recordAuditLog('VERIFY_FILE', 'INFO', `Verifying file structure for '${file.originalname}'...`);

    const buf = file.buffer;
    if (buf.length < HEADER_FIXED_SIZE) {
      recordAuditLog('VERIFY_FILE', 'FAILED', 'File buffer too small for header.');
      return res.json({ valid: false, message: '«Invalid, corrupted, tampered, or unsupported ECR file.»' });
    }

    const magic = buf.subarray(0, 4);
    if (!magic.equals(MAGIC_HEADER)) {
      recordAuditLog('VERIFY_FILE', 'FAILED', 'Magic header mismatch.');
      return res.json({ valid: false, message: '«Invalid, corrupted, tampered, or unsupported ECR file.»' });
    }

    const version = buf.readUInt16BE(4);
    const iterations = buf.readUInt32BE(7);

    if (version !== 1 || iterations < 10000) {
      recordAuditLog('VERIFY_FILE', 'FAILED', 'Invalid version or iteration count.');
      return res.json({ valid: false, message: '«Invalid, corrupted, tampered, or unsupported ECR file.»' });
    }

    recordAuditLog('VERIFY_FILE', 'SUCCESS', `File structure verified valid for '${file.originalname}'.`);

    return res.json({
      valid: true,
      message: '✔ ECR Header Signature, Version, and Layout Structure Valid.',
      details: {
        magic: magic.toString('ascii'),
        version,
        kdfAlgorithm: 'PBKDF2WithHmacSHA512',
        iterations,
        fileSize: buf.length
      }
    });
  } catch (err: any) {
    recordAuditLog('VERIFY_FILE', 'FAILED', err.message);
    return res.json({ valid: false, message: '«Invalid, corrupted, tampered, or unsupported ECR file.»' });
  }
});

// 4. Info Inspection API
app.post('/api/info', upload.single('file'), (req, res) => {
  try {
    const file = req.file;
    if (!file) return res.status(400).json({ error: 'No file uploaded' });

    recordAuditLog('FILE_INFO', 'INFO', `Inspecting metadata for '${file.originalname}'...`);

    const buf = file.buffer;
    if (buf.length < HEADER_FIXED_SIZE) {
      return res.status(400).json({ error: '«Invalid, corrupted, tampered, or unsupported ECR file.»' });
    }

    const magic = buf.subarray(0, 4);
    if (!magic.equals(MAGIC_HEADER)) {
      return res.status(400).json({ error: '«Invalid, corrupted, tampered, or unsupported ECR file.»' });
    }

    const version = buf.readUInt16BE(4);
    const iterations = buf.readUInt32BE(7);
    const salt = buf.subarray(11, 43);
    const nonce = buf.subarray(43, 55);
    const metadataLen = buf.readUInt32BE(55);

    const metadataBytes = buf.subarray(HEADER_FIXED_SIZE, HEADER_FIXED_SIZE + metadataLen);
    const metadata = JSON.parse(metadataBytes.toString('utf-8'));

    const ciphertextLen = buf.length - HEADER_FIXED_SIZE - metadataLen;

    return res.json({
      magicHex: magic.toString('hex').toUpperCase(),
      magicAscii: magic.toString('ascii'),
      version,
      kdfAlgorithm: 'PBKDF2WithHmacSHA512 (AES-256-GCM)',
      iterations,
      saltHex: salt.toString('hex').toUpperCase(),
      nonceHex: nonce.toString('hex').toUpperCase(),
      metadata,
      hasSignature: !!(metadata.sig && metadata.pubKey),
      ciphertextLength: ciphertextLen,
      totalSize: buf.length
    });
  } catch (err: any) {
    return res.status(400).json({ error: '«Invalid, corrupted, tampered, or unsupported ECR file.»' });
  }
});

// 5. Tamper Test API
app.post('/api/tamper-test', upload.single('file'), (req, res) => {
  try {
    const file = req.file;
    const password = req.body.password;
    if (!file || !password) return res.status(400).json({ error: 'Missing file or password' });

    recordAuditLog('TAMPER_TEST', 'INFO', `Running deliberate bit-flip tamper test on '${file.originalname}'...`);

    // Tamper by flipping a bit in the ciphertext payload
    const corruptedBuf = Buffer.from(file.buffer);
    const flipIndex = corruptedBuf.length - 20; // Flip a byte in ciphertext
    corruptedBuf[flipIndex] ^= 0xFF; // Bit invert

    try {
      decryptEcrBuffer(corruptedBuf, password);
      recordAuditLog('TAMPER_TEST', 'FAILED', 'CRITICAL FAILURE: Decryption passed on tampered buffer!');
      return res.json({ tampered: true, authTagBlocked: false, result: 'UNEXPECTED: Decryption passed on tampered data!' });
    } catch (e: any) {
      recordAuditLog('TAMPER_TEST', 'SUCCESS', 'Auth tag successfully blocked tampered ciphertext byte.');
      return res.json({
        tampered: true,
        authTagBlocked: true,
        byteFlippedIndex: flipIndex,
        errorMessage: '«Invalid, corrupted, tampered, or unsupported ECR file.»',
        explanation: 'AES-256-GCM Authentication Tag check failed! Tampered byte detected and rejected before writing plaintext.'
      });
    }
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 6. Generate Sample Zip Endpoint
app.get('/api/sample-zip', (req, res) => {
  const zip = new AdmZip();
  zip.addFile('secret_document.txt', Buffer.from('CONFIDENTIAL DATA: Top secret Java 26 ECR Encryption Project details.\nCreated at ' + new Date().toISOString()));
  zip.addFile('readme.md', Buffer.from('# ECR Encryption Test Archive v2.1\nThis archive was encrypted with Java 26 ECR Manager with streaming & optional digital signature.'));
  const zipBuf = zip.toBuffer();

  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="sample_secrets.zip"');
  return res.send(zipBuf);
});

// 7. Get Java Source Code Tree API
const JAVA_DIR = path.join(process.cwd(), 'src', 'java_code');

function getJavaFilesRecursively(dir: string, baseDir = dir): { path: string; name: string; content: string }[] {
  let results: { path: string; name: string; content: string }[] = [];
  if (!fs.existsSync(dir)) return [];

  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      results = results.concat(getJavaFilesRecursively(fullPath, baseDir));
    } else if (file.endsWith('.java')) {
      const relativePath = path.relative(baseDir, fullPath);
      const content = fs.readFileSync(fullPath, 'utf-8');
      results.push({
        path: relativePath,
        name: file,
        content
      });
    }
  });
  return results;
}

app.get('/api/java-sources', (req, res) => {
  const files = getJavaFilesRecursively(JAVA_DIR);
  return res.json({ count: files.length, files });
});

// 8. Download complete Java 26 project zip
app.get('/api/download-java-project', (req, res) => {
  const zip = new AdmZip();

  // Add all java files under src/
  const javaFiles = getJavaFilesRecursively(JAVA_DIR);
  javaFiles.forEach(f => {
    zip.addFile(`src/${f.path}`, Buffer.from(f.content, 'utf-8'));
  });

  // Add build scripts
  const compileSh = `#!/bin/bash
# Java 26 Build & Run Script
echo "Compiling Java 26 ECR Encryption Manager v2.1..."
mkdir -p bin
javac -d bin $(find src -name "*.java")

if [ $? -eq 0 ]; then
    echo "Compilation successful! Starting ECR Encryption Manager..."
    java -cp bin com.ecr.Main
else
    echo "Compilation failed."
fi
`;
  zip.addFile('compile.sh', Buffer.from(compileSh, 'utf-8'));

  const readmeMd = `# ECR Encryption Manager v2.1 (Java 26)

High Security Terminal Encryption Manager providing AES-256-GCM authenticated encryption for ZIP to ECR format conversion with chunked streaming, optional Ed25519 digital signatures, secure configuration management, and audit logging.

## Requirements
- Java 26 JDK

## Compilation & Run
\`\`\`bash
chmod +x compile.sh
./compile.sh
\`\`\`

Or manually:
\`\`\`bash
mkdir -p bin
javac -d bin $(find src -name "*.java")
java -cp bin com.ecr.Main
\`\`\`
`;
  zip.addFile('README.md', Buffer.from(readmeMd, 'utf-8'));

  const zipBuf = zip.toBuffer();
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="ECR_Encryption_Manager_Java26.zip"');
  return res.send(zipBuf);
});

// --- VITE MIDDLEWARE ---
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ECR Manager v2.1 Server running on http://localhost:${PORT}`);
  });
}

startServer();
