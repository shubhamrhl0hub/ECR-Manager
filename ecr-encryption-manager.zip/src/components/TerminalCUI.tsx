import React, { useState, useRef, useEffect } from 'react';
import { Terminal, Lock, Unlock, ShieldCheck, Info, FileText, Play, Download, Sparkles, AlertTriangle, CheckCircle2, RefreshCw, Settings, ListFilter } from 'lucide-react';

interface TerminalCUIProps {
  onOpenJavaSources: () => void;
  onOpenTamperTest: () => void;
}

export const TerminalCUI: React.FC<TerminalCUIProps> = ({ onOpenJavaSources, onOpenTamperTest }) => {
  const [activeOption, setActiveOption] = useState<number | null>(null);
  const [logs, setLogs] = useState<Array<{ type: 'input' | 'system' | 'success' | 'error' | 'info'; text: string; time: string }>>([
    { type: 'system', text: 'ECR High Security Terminal Encryption Manager v2.1 (Java 26) - Developer: $HUBHAM', time: new Date().toLocaleTimeString() },
    { type: 'info', text: 'Type a menu option number (1-7) or click any action below.', time: new Date().toLocaleTimeString() }
  ]);

  const [commandInput, setCommandInput] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [iterations, setIterations] = useState(210000);
  const [chunkSizeKB, setChunkSizeKB] = useState(64);
  const [enableDigitalSigs, setEnableDigitalSigs] = useState(true);
  const [maxLogMB, setMaxLogMB] = useState(5);
  const [maxLogFiles, setMaxLogFiles] = useState(5);

  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressStage, setProgressStage] = useState('');
  const [serverAuditLogs, setServerAuditLogs] = useState<string[]>([]);

  const logContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  const fetchConfig = async () => {
    try {
      const res = await fetch('/api/config');
      if (res.ok) {
        const data = await res.json();
        setIterations(data.config.kdfIterations);
        setChunkSizeKB(Math.round(data.config.chunkSizeBytes / 1024));
        setEnableDigitalSigs(data.config.enableDigitalSignatures);
        setMaxLogMB(data.config.maxLogSizeMB);
        setMaxLogFiles(data.config.maxLogFiles);
      }
    } catch (e) {
      // ignore
    }
  };

  const fetchAuditLogs = async () => {
    try {
      const res = await fetch('/api/audit-logs');
      if (res.ok) {
        const data = await res.json();
        setServerAuditLogs(data.logs || []);
      }
    } catch (e) {
      // ignore
    }
  };

  useEffect(() => {
    fetchConfig();
    fetchAuditLogs();
  }, []);

  const addLog = (type: 'input' | 'system' | 'success' | 'error' | 'info', text: string) => {
    setLogs((prev) => [...prev, { type, text, time: new Date().toLocaleTimeString() }]);
  };

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = commandInput.trim();
    if (!cmd) return;

    addLog('input', `$ ${cmd}`);
    setCommandInput('');

    switch (cmd) {
      case '1':
        setActiveOption(1);
        addLog('info', '--- Option 1 Selected: Create Encrypted File (.zip -> .ecr) ---');
        break;
      case '2':
        setActiveOption(2);
        addLog('info', '--- Option 2 Selected: Decrypt Encrypted File (.ecr -> .zip) ---');
        break;
      case '3':
        setActiveOption(3);
        addLog('info', '--- Option 3 Selected: Verify Encrypted File Header & Integrity ---');
        break;
      case '4':
        setActiveOption(4);
        addLog('info', '--- Option 4 Selected: Display File Information & Cryptographic Metadata ---');
        break;
      case '5':
        setActiveOption(5);
        fetchConfig();
        fetchAuditLogs();
        addLog('info', '--- Option 5 Selected: View Secure Configuration & Audit Log ---');
        break;
      case '6':
        setActiveOption(6);
        addLog('info', '--- Option 6 Selected: Security Specification & Help ---');
        break;
      case '7':
        onOpenJavaSources();
        addLog('info', '--- Option 7 Selected: Opening Java 26 Source Code Tree ---');
        break;
      case 'clear':
        setLogs([]);
        break;
      case 'help':
        addLog('system', 'Available Commands: 1 (Encrypt), 2 (Decrypt), 3 (Verify), 4 (Info), 5 (Config & Audit Log), 6 (Help), 7 (Java Code), clear');
        break;
      default:
        addLog('error', `Unknown option: "${cmd}". Enter a number between 1 and 7.`);
        break;
    }
  };

  const updateServerConfig = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chunkSizeBytes: chunkSizeKB * 1024,
          kdfIterations: iterations,
          enableDigitalSignatures: enableDigitalSigs,
          maxLogSizeMB: maxLogMB,
          maxLogFiles: maxLogFiles
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        addLog('success', `✔ SECURE CONFIGURATION UPDATED & VERIFIED: PBKDF2 Iterations=${iterations.toLocaleString()}, Chunk=${chunkSizeKB}KB, LogMax=${maxLogMB}MB.`);
        fetchAuditLogs();
      } else {
        addLog('error', `Configuration update error: ${data.error}`);
      }
    } catch (e: any) {
      addLog('error', `Failed to update configuration: ${e.message}`);
    } finally {
      setLoading(false);
    }
  };

  // 1. Encrypt Action
  const runEncryption = async () => {
    if (!selectedFile) {
      addLog('error', 'Error: Please select a source .zip file.');
      return;
    }
    if (!password) {
      addLog('error', 'Error: Password cannot be empty.');
      return;
    }
    if (password !== confirmPassword) {
      addLog('error', 'Error: Encryption passwords do not match!');
      return;
    }

    setLoading(true);
    setProgress(10);
    setProgressStage('Validating PKZIP structure and computing SHA-256...');

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('password', password);
      formData.append('iterations', iterations.toString());

      setProgress(40);
      setProgressStage(`Deriving key via PBKDF2-HMAC-SHA512 (${iterations.toLocaleString()} iterations)...`);

      const res = await fetch('/api/encrypt', {
        method: 'POST',
        body: formData
      });

      if (!res.ok) {
        const errJson = await res.json();
        throw new Error(errJson.error || 'Encryption failed');
      }

      setProgress(80);
      setProgressStage('Encrypting payload using AES-256-GCM and adding 128-bit Auth Tag...');

      const blob = await res.blob();
      const outName = selectedFile.name.replace(/\.zip$/i, '') + '.ecr';

      // Download file
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = outName;
      a.click();
      window.URL.revokeObjectURL(url);

      setProgress(100);
      setProgressStage('Zeroizing password buffer in memory...');

      addLog('success', `Encryption completed successfully.\n\nYour ZIP file has been encrypted into an ECR file with no detected errors.\nOutput file: ${outName}`);
      addLog('info', 'Memory Audit: Sensitive password buffers scrubbed.');

      setPassword('');
      setConfirmPassword('');
      setSelectedFile(null);
      fetchAuditLogs();
    } catch (err: any) {
      addLog('error', `✖ ENCRYPTION FAILED: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // 2. Decrypt Action
  const runDecryption = async () => {
    if (!selectedFile) {
      addLog('error', 'Error: Please select an .ecr file to decrypt.');
      return;
    }
    if (!password) {
      addLog('error', 'Error: Enter decryption password.');
      return;
    }

    setLoading(true);
    setProgress(20);
    setProgressStage('Reading ECR binary container header & magic bytes...');

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('password', password);

      setProgress(60);
      setProgressStage('Authenticating AES-256-GCM Tag and validating SHA-256 payload checksum...');

      const res = await fetch('/api/decrypt', {
        method: 'POST',
        body: formData
      });

      if (!res.ok) {
        const errJson = await res.json();
        throw new Error(errJson.error || '«Invalid, corrupted, tampered, or unsupported ECR file.»');
      }

      const blob = await res.blob();
      const outName = selectedFile.name.replace(/\.ecr$/i, '') + '_decrypted.zip';

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = outName;
      a.click();
      window.URL.revokeObjectURL(url);

      setProgress(100);
      setProgressStage('Decryption complete.');

      addLog('success', `Decryption completed successfully.\n\nYour ECR file has been restored to the original ZIP file with no detected errors.\nRestored archive: ${outName}`);
      addLog('info', 'Memory Audit: Key memory zeroized.');

      setPassword('');
      setSelectedFile(null);
      fetchAuditLogs();
    } catch (err: any) {
      addLog('error', err.message || '«Invalid, corrupted, tampered, or unsupported ECR file.»');
    } finally {
      setLoading(false);
    }
  };

  // 3. Verify Action
  const runVerify = async () => {
    if (!selectedFile) {
      addLog('error', 'Error: Please select an .ecr file to verify.');
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', selectedFile);

      const res = await fetch('/api/verify', { method: 'POST', body: formData });
      const data = await res.json();

      if (data.valid) {
        addLog('success', `✔ ${data.message}`);
        addLog('info', `Magic: ${data.details.magic} | Version: ${data.details.version} | KDF: ${data.details.kdfAlgorithm} (${data.details.iterations.toLocaleString()} iter)`);
      } else {
        addLog('error', `«Invalid, corrupted, tampered, or unsupported ECR file.»`);
      }
      fetchAuditLogs();
    } catch (err: any) {
      addLog('error', '«Invalid, corrupted, tampered, or unsupported ECR file.»');
    } finally {
      setLoading(false);
    }
  };

  // 4. Info Action
  const runInfo = async () => {
    if (!selectedFile) {
      addLog('error', 'Error: Please select an .ecr file.');
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', selectedFile);

      const res = await fetch('/api/info', { method: 'POST', body: formData });
      const data = await res.json();

      if (res.ok) {
        addLog('system', `=== METADATA INSPECTION FOR ${selectedFile.name} ===`);
        addLog('info', `Magic Header      : ${data.magicAscii} (0x${data.magicHex})`);
        addLog('info', `Format Version    : ${data.version}`);
        addLog('info', `KDF Algorithm     : ${data.kdfAlgorithm} (${data.iterations.toLocaleString()} iterations)`);
        addLog('info', `Salt (256-bit)    : ${data.saltHex}`);
        addLog('info', `Nonce (96-bit)    : ${data.nonceHex}`);
        addLog('info', `Original File     : ${data.metadata.file} (${data.metadata.size.toLocaleString()} bytes)`);
        addLog('info', `SHA-256 Checksum  : ${data.metadata.sha256}`);
        addLog('info', `Ciphertext Size   : ${data.ciphertextLength.toLocaleString()} bytes (incl. 16B GCM Tag)`);
        addLog('success', `Status            : ECR File Structure Validated`);
      } else {
        addLog('error', `«Invalid, corrupted, tampered, or unsupported ECR file.»`);
      }
      fetchAuditLogs();
    } catch (err: any) {
      addLog('error', '«Invalid, corrupted, tampered, or unsupported ECR file.»');
    } finally {
      setLoading(false);
    }
  };

  // Download Sample Zip
  const downloadSampleZip = async () => {
    addLog('info', 'Generating test ZIP archive with secret files...');
    try {
      const res = await fetch('/api/sample-zip');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'sample_secrets.zip';
      a.click();
      window.URL.revokeObjectURL(url);
      addLog('success', '✔ Downloaded sample_secrets.zip to test encryption.');
    } catch (e: any) {
      addLog('error', 'Failed to generate sample zip.');
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-full">
      {/* Terminal Viewport */}
      <div className="flex-1 flex flex-col bg-slate-950 border border-emerald-900/60 rounded-xl shadow-2xl overflow-hidden font-mono text-xs sm:text-sm">
        {/* Terminal Header */}
        <div className="bg-slate-900 border-b border-emerald-900/40 px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
            </div>
            <span className="ml-2 text-emerald-400 font-semibold tracking-wide flex items-center gap-1.5 text-xs">
              <Terminal className="w-3.5 h-3.5" />
              ecr-manager@java26-terminal:~
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={downloadSampleZip}
              className="px-2.5 py-1 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800/60 rounded flex items-center gap-1 transition"
              title="Download test ZIP"
            >
              <Download className="w-3 h-3" />
              Get Sample .zip
            </button>
            <button
              onClick={onOpenTamperTest}
              className="px-2.5 py-1 bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-800/60 rounded flex items-center gap-1 transition"
            >
              <AlertTriangle className="w-3 h-3" />
              Tamper Test
            </button>
            <button
              onClick={() => setLogs([])}
              className="px-2 py-1 text-slate-400 hover:text-slate-200"
              title="Clear Terminal Output"
            >
              Clear
            </button>
          </div>
        </div>

        {/* ASCII Banner & Output Stream */}
        <div ref={logContainerRef} className="flex-1 p-4 overflow-y-auto space-y-2 bg-slate-950 text-slate-200">
          <pre className="text-emerald-500/90 text-[10px] leading-3 font-bold select-none hidden sm:block">
{`
┌─────────────────────────────────────────────────────────────────────────────┐
│   ECR HIGH SECURITY TERMINAL ENCRYPTION MANAGER v2.1 (Java 26)              │
│   AES-256-GCM • PBKDF2 • Ed25519 • Secure Config • Sanitized Audit Logger     │
│   Developer: $HUBHAM                                                        │
└─────────────────────────────────────────────────────────────────────────────┘
`}
          </pre>

          {/* Menu Options Reference */}
          <div className="p-3 bg-emerald-950/30 border border-emerald-900/40 rounded-lg space-y-1 my-2">
            <div className="text-emerald-400 font-bold mb-1 flex items-center justify-between">
              <span>MAIN MENU OPTIONS:</span>
              <span className="text-[11px] text-emerald-600 font-normal">Click or enter option number</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 text-xs">
              <button onClick={() => { setActiveOption(1); addLog('info', 'Selected 1. Encrypt'); }} className="text-left hover:text-emerald-300 text-slate-300 flex items-center gap-1.5">
                <span className="text-emerald-400 font-bold">1.</span> Create Encrypted File (.zip → .ecr)
              </button>
              <button onClick={() => { setActiveOption(2); addLog('info', 'Selected 2. Decrypt'); }} className="text-left hover:text-emerald-300 text-slate-300 flex items-center gap-1.5">
                <span className="text-emerald-400 font-bold">2.</span> Decrypt Encrypted File (.ecr → .zip)
              </button>
              <button onClick={() => { setActiveOption(3); addLog('info', 'Selected 3. Verify'); }} className="text-left hover:text-emerald-300 text-slate-300 flex items-center gap-1.5">
                <span className="text-emerald-400 font-bold">3.</span> Verify Header & Integrity
              </button>
              <button onClick={() => { setActiveOption(4); addLog('info', 'Selected 4. File Info'); }} className="text-left hover:text-emerald-300 text-slate-300 flex items-center gap-1.5">
                <span className="text-emerald-400 font-bold">4.</span> Display File Information
              </button>
              <button onClick={() => { setActiveOption(5); fetchConfig(); fetchAuditLogs(); addLog('info', 'Selected 5. Secure Config & Audit Log'); }} className="text-left hover:text-emerald-300 text-slate-300 flex items-center gap-1.5">
                <span className="text-emerald-400 font-bold">5.</span> Secure Configuration & Audit Log
              </button>
              <button onClick={() => { setActiveOption(6); addLog('info', 'Selected 6. Security Spec'); }} className="text-left hover:text-emerald-300 text-slate-300 flex items-center gap-1.5">
                <span className="text-emerald-400 font-bold">6.</span> Security Spec & Help
              </button>
              <button onClick={onOpenJavaSources} className="col-span-1 sm:col-span-2 text-left hover:text-emerald-300 text-slate-300 flex items-center gap-1.5 pt-1">
                <span className="text-emerald-400 font-bold">7.</span> Open Java 26 Source Code Tree
              </button>
            </div>
          </div>

          {/* Logs Output */}
          {logs.map((log, index) => (
            <div key={index} className="leading-relaxed break-words">
              <span className="text-slate-600 text-[11px] mr-2">[{log.time}]</span>
              {log.type === 'input' && <span className="text-emerald-400 font-bold">{log.text}</span>}
              {log.type === 'system' && <span className="text-cyan-400 font-semibold">{log.text}</span>}
              {log.type === 'success' && <span className="text-emerald-400 whitespace-pre-line">{log.text}</span>}
              {log.type === 'error' && <span className="text-rose-400 font-semibold">{log.text}</span>}
              {log.type === 'info' && <span className="text-slate-300">{log.text}</span>}
            </div>
          ))}

          {loading && (
            <div className="py-2 space-y-1">
              <div className="flex items-center justify-between text-xs text-emerald-400">
                <span>{progressStage}</span>
                <span>{progress}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded overflow-hidden">
                <div className="bg-emerald-500 h-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
              </div>
            </div>
          )}
        </div>

        {/* Command Line Input */}
        <form onSubmit={handleCommandSubmit} className="bg-slate-900 border-t border-emerald-900/40 p-3 flex items-center gap-2">
          <span className="text-emerald-400 font-bold">$</span>
          <input
            type="text"
            value={commandInput}
            onChange={(e) => setCommandInput(e.target.value)}
            placeholder="Enter menu option (1-7) or command..."
            className="flex-1 bg-transparent text-emerald-300 focus:outline-none font-mono placeholder:text-slate-600"
          />
          <button type="submit" className="px-3 py-1 bg-emerald-800 hover:bg-emerald-700 text-emerald-100 rounded text-xs font-semibold">
            Execute
          </button>
        </form>
      </div>

      {/* Action Workspace / Interactive Controls Panel */}
      <div className="w-full lg:w-96 bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col gap-4 text-slate-200">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-slate-100 flex items-center gap-2 text-sm">
            {activeOption === 1 && <Lock className="w-4 h-4 text-emerald-400" />}
            {activeOption === 2 && <Unlock className="w-4 h-4 text-cyan-400" />}
            {activeOption === 3 && <ShieldCheck className="w-4 h-4 text-amber-400" />}
            {activeOption === 4 && <Info className="w-4 h-4 text-blue-400" />}
            {activeOption === 5 && <Settings className="w-4 h-4 text-emerald-400" />}
            {activeOption === 6 && <FileText className="w-4 h-4 text-purple-400" />}
            {!activeOption && <Sparkles className="w-4 h-4 text-emerald-400" />}
            {activeOption === 1 && 'Option 1: Encrypt ZIP to ECR'}
            {activeOption === 2 && 'Option 2: Decrypt ECR to ZIP'}
            {activeOption === 3 && 'Option 3: Verify ECR File'}
            {activeOption === 4 && 'Option 4: Display File Metadata'}
            {activeOption === 5 && 'Option 5: Config & Audit Log'}
            {activeOption === 6 && 'Option 6: Security Spec'}
            {!activeOption && 'Select Action'}
          </h3>

          <div className="flex gap-1">
            {[1, 2, 3, 4, 5, 6].map((num) => (
              <button
                key={num}
                onClick={() => {
                  setActiveOption(num);
                  if (num === 5) { fetchConfig(); fetchAuditLogs(); }
                  addLog('info', `Selected Option ${num}`);
                }}
                className={`w-6 h-6 rounded text-xs font-bold transition ${
                  activeOption === num ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                {num}
              </button>
            ))}
          </div>
        </div>

        {/* Option 1: Encrypt Form */}
        {activeOption === 1 && (
          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">Source ZIP Archive (.zip)</label>
              <input
                type="file"
                accept=".zip"
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                className="w-full text-slate-300 bg-slate-950 border border-slate-800 rounded p-2 text-xs file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:bg-emerald-950 file:text-emerald-400 hover:file:bg-emerald-900 cursor-pointer"
              />
              {selectedFile && <p className="text-emerald-400 mt-1">Selected: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)</p>}
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Encryption Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter secret password..."
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Confirm Password</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm password..."
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">PBKDF2 Iteration Count</label>
              <select
                value={iterations}
                onChange={(e) => setIterations(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 focus:outline-none"
              >
                <option value={210000}>210,000 Iterations (Standard High Security)</option>
                <option value={500000}>500,000 Iterations (Ultra Hardened)</option>
                <option value={1000000}>1,000,000 Iterations (Maximum Resistance)</option>
              </select>
            </div>

            <button
              onClick={runEncryption}
              disabled={loading}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded flex items-center justify-center gap-2 transition disabled:opacity-50"
            >
              {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
              Convert .zip → .ecr
            </button>
          </div>
        )}

        {/* Option 2: Decrypt Form */}
        {activeOption === 2 && (
          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">Encrypted Container (.ecr)</label>
              <input
                type="file"
                accept=".ecr"
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                className="w-full text-slate-300 bg-slate-950 border border-slate-800 rounded p-2 text-xs file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:bg-cyan-950 file:text-cyan-400 hover:file:bg-cyan-900 cursor-pointer"
              />
              {selectedFile && <p className="text-cyan-400 mt-1">Selected: {selectedFile.name}</p>}
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Decryption Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password..."
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <button
              onClick={runDecryption}
              disabled={loading}
              className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded flex items-center justify-center gap-2 transition disabled:opacity-50"
            >
              {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Unlock className="w-4 h-4" />}
              Decrypt .ecr → .zip
            </button>
          </div>
        )}

        {/* Option 3: Verify Form */}
        {activeOption === 3 && (
          <div className="space-y-4 text-xs">
            <p className="text-slate-400">Verifies header signature magic bytes (`ECR1`), version compliance, and structure without needing the decryption password.</p>
            <div>
              <label className="block text-slate-400 font-medium mb-1">Target ECR File</label>
              <input
                type="file"
                accept=".ecr"
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                className="w-full text-slate-300 bg-slate-950 border border-slate-800 rounded p-2 text-xs"
              />
            </div>

            <button
              onClick={runVerify}
              disabled={loading}
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded flex items-center justify-center gap-2 transition disabled:opacity-50"
            >
              <ShieldCheck className="w-4 h-4" />
              Verify Header Integrity
            </button>
          </div>
        )}

        {/* Option 4: File Info */}
        {activeOption === 4 && (
          <div className="space-y-4 text-xs">
            <p className="text-slate-400">Displays cryptographic parameters (Salt, IV, Metadata payload, Ciphertext byte size).</p>
            <div>
              <label className="block text-slate-400 font-medium mb-1">Target ECR File</label>
              <input
                type="file"
                accept=".ecr"
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                className="w-full text-slate-300 bg-slate-950 border border-slate-800 rounded p-2 text-xs"
              />
            </div>

            <button
              onClick={runInfo}
              disabled={loading}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-slate-950 font-bold rounded flex items-center justify-center gap-2 transition disabled:opacity-50"
            >
              <Info className="w-4 h-4" />
              Inspect Metadata
            </button>
          </div>
        )}

        {/* Option 5: Secure Configuration & Audit Log */}
        {activeOption === 5 && (
          <div className="space-y-4 text-xs">
            <div className="border border-emerald-900/60 bg-slate-950 p-3 rounded-lg space-y-3">
              <h4 className="font-bold text-emerald-400 flex items-center gap-1.5">
                <Settings className="w-3.5 h-3.5" />
                Secure Application Configuration
              </h4>

              <div>
                <label className="block text-slate-400 mb-1">Streaming Chunk Size ({chunkSizeKB} KB)</label>
                <input
                  type="range"
                  min={16}
                  max={1024}
                  step={16}
                  value={chunkSizeKB}
                  onChange={(e) => setChunkSizeKB(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">PBKDF2 Iterations ({iterations.toLocaleString()})</label>
                <input
                  type="range"
                  min={100000}
                  max={1000000}
                  step={50000}
                  value={iterations}
                  onChange={(e) => setIterations(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-300">Digital Signatures (Ed25519)</span>
                <input
                  type="checkbox"
                  checked={enableDigitalSigs}
                  onChange={(e) => setEnableDigitalSigs(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500 cursor-pointer"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 mb-0.5">Max Log Size (MB)</label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={maxLogMB}
                    onChange={(e) => setMaxLogMB(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded p-1 text-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-0.5">Max Log Files</label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={maxLogFiles}
                    onChange={(e) => setMaxLogFiles(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded p-1 text-slate-200"
                  />
                </div>
              </div>

              <button
                onClick={updateServerConfig}
                disabled={loading}
                className="w-full py-2 bg-emerald-700 hover:bg-emerald-600 text-slate-950 font-bold rounded flex items-center justify-center gap-1.5 transition"
              >
                Apply & Save Configuration
              </button>
            </div>

            <div className="border border-slate-800 bg-slate-950 p-3 rounded-lg space-y-2 max-h-52 overflow-y-auto font-mono text-[11px]">
              <div className="flex items-center justify-between text-slate-400 font-bold border-b border-slate-800 pb-1">
                <span className="flex items-center gap-1 text-slate-300">
                  <ListFilter className="w-3.5 h-3.5 text-cyan-400" />
                  Security Audit Log Stream
                </span>
                <button onClick={fetchAuditLogs} className="text-emerald-400 hover:underline">Refresh</button>
              </div>
              {serverAuditLogs.length === 0 ? (
                <p className="text-slate-500 italic">No audit log entries recorded yet.</p>
              ) : (
                serverAuditLogs.slice(-10).map((log, idx) => (
                  <div key={idx} className="text-slate-300 leading-tight break-all border-b border-slate-900/60 pb-1">
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Option 6: Security Spec */}
        {activeOption === 6 && (
          <div className="space-y-3 text-xs text-slate-300">
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-emerald-400 font-bold block mb-1">Cipher Standard</span>
              AES-256-GCM with 128-bit authentication tag. Protects against bit-flipping and padding attacks.
            </div>
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-emerald-400 font-bold block mb-1">Key Derivation</span>
              PBKDF2-HMAC-SHA512 (210,000+ iterations) using 256-bit unique salt.
            </div>
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-emerald-400 font-bold block mb-1">Memory Hygiene</span>
              Sensitives arrays (`char[] password`, `byte[] derivedKey`) explicitly zeroized post-encryption.
            </div>
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-emerald-400 font-bold block mb-1">Secure Configuration & Audit</span>
              Strict parameter bounds, sanitized event logging, and automatic file rotation.
            </div>
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-emerald-400 font-bold block mb-1">Developer</span>
              $HUBHAM
            </div>
          </div>
        )}

        {!activeOption && (
          <div className="p-4 bg-slate-950 rounded border border-slate-800 text-center text-xs text-slate-400 space-y-3">
            <p>Select any option from the top menu or type a command number (1-7) in the terminal line.</p>
            <div className="flex flex-col gap-2">
              <button onClick={() => setActiveOption(1)} className="p-2 bg-emerald-950/60 border border-emerald-800 text-emerald-300 rounded font-semibold hover:bg-emerald-900 transition">
                Start Option 1: Encrypt .zip
              </button>
              <button onClick={() => setActiveOption(2)} className="p-2 bg-cyan-950/60 border border-cyan-800 text-cyan-300 rounded font-semibold hover:bg-cyan-900 transition">
                Start Option 2: Decrypt .ecr
              </button>
              <button onClick={() => { setActiveOption(5); fetchConfig(); fetchAuditLogs(); }} className="p-2 bg-slate-800 border border-slate-700 text-slate-200 rounded font-semibold hover:bg-slate-700 transition">
                View Secure Config & Audit Log
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
