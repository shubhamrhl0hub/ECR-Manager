import React from 'react';
import { Layers, ShieldCheck, Binary, Key, Lock, Eye } from 'lucide-react';

export const BinaryInspector: React.FC = () => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 text-slate-200 space-y-6 font-sans">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Binary className="w-5 h-5 text-emerald-400" />
            .ECR Binary Custom File Format Specification
          </h2>
          <p className="text-xs text-slate-400">Authenticated binary envelope layout for maximum practical security</p>
        </div>
        <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold rounded-full">
          Format Version v1.0
        </span>
      </div>

      {/* Visual Layout Diagram */}
      <div className="space-y-3 font-mono text-xs">
        <h3 className="font-bold text-slate-300 text-xs uppercase tracking-wider">59-Byte Fixed Header + Metadata + Authenticated Ciphertext</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-7 gap-2">
          <div className="p-3 bg-emerald-950/80 border border-emerald-700/60 rounded-lg md:col-span-1">
            <span className="text-[10px] text-emerald-400 font-bold block">MAGIC HEADER</span>
            <span className="text-slate-100 font-bold">4 Bytes</span>
            <p className="text-[10px] text-slate-400 mt-1">ASCII "ECR1" (0x45 43 52 31)</p>
          </div>

          <div className="p-3 bg-cyan-950/80 border border-cyan-700/60 rounded-lg md:col-span-1">
            <span className="text-[10px] text-cyan-400 font-bold block">VERSION & KDF</span>
            <span className="text-slate-100 font-bold">7 Bytes</span>
            <p className="text-[10px] text-slate-400 mt-1">v1, PBKDF2 Iterations</p>
          </div>

          <div className="p-3 bg-blue-950/80 border border-blue-700/60 rounded-lg md:col-span-1">
            <span className="text-[10px] text-blue-400 font-bold block">RANDOM SALT</span>
            <span className="text-slate-100 font-bold">32 Bytes</span>
            <p className="text-[10px] text-slate-400 mt-1">256-bit CSPRNG Salt</p>
          </div>

          <div className="p-3 bg-purple-950/80 border border-purple-700/60 rounded-lg md:col-span-1">
            <span className="text-[10px] text-purple-400 font-bold block">RANDOM NONCE</span>
            <span className="text-slate-100 font-bold">12 Bytes</span>
            <p className="text-[10px] text-slate-400 mt-1">96-bit AES-GCM IV</p>
          </div>

          <div className="p-3 bg-amber-950/80 border border-amber-700/60 rounded-lg md:col-span-1">
            <span className="text-[10px] text-amber-400 font-bold block">METADATA LEN</span>
            <span className="text-slate-100 font-bold">4 Bytes</span>
            <p className="text-[10px] text-slate-400 mt-1">Uint32 BigEndian</p>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-700 rounded-lg md:col-span-1">
            <span className="text-[10px] text-slate-300 font-bold block">METADATA JSON</span>
            <span className="text-slate-100 font-bold">Variable</span>
            <p className="text-[10px] text-slate-400 mt-1">Filename, SHA-256</p>
          </div>

          <div className="p-3 bg-rose-950/80 border border-rose-700/60 rounded-lg md:col-span-1">
            <span className="text-[10px] text-rose-400 font-bold block">CIPHERTEXT + TAG</span>
            <span className="text-slate-100 font-bold">Payload + 16B</span>
            <p className="text-[10px] text-slate-400 mt-1">AES-256-GCM + Tag</p>
          </div>
        </div>
      </div>

      {/* Security Guarantees */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-800 text-xs">
        <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <Lock className="w-4 h-4" />
            AES-256-GCM Authenticated Cipher
          </div>
          <p className="text-slate-400 leading-relaxed">
            Symmetric authenticated encryption provides both confidentiality and data authenticity. Plaintext zip contents never appear anywhere in unencrypted form.
          </p>
        </div>

        <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-amber-400 font-bold">
            <Key className="w-4 h-4" />
            Hardened Key Derivation
          </div>
          <p className="text-slate-400 leading-relaxed">
            PBKDF2 with HMAC-SHA512 using 210,000+ iterations prevents dictionary and brute force attacks. Each file receives a unique 256-bit random salt.
          </p>
        </div>

        <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-rose-400 font-bold">
            <ShieldCheck className="w-4 h-4" />
            128-bit Tamper Detection
          </div>
          <p className="text-slate-400 leading-relaxed">
            GCM Galois Authentication Tag verifies file integrity prior to decryption. Any single modified byte immediately triggers tamper rejection.
          </p>
        </div>
      </div>
    </div>
  );
};
