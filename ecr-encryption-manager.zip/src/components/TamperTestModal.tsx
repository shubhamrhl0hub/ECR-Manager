import React, { useState } from 'react';
import { AlertTriangle, ShieldAlert, CheckCircle2, XCircle, RefreshCw, X } from 'lucide-react';

interface TamperTestModalProps {
  onClose: () => void;
}

export const TamperTestModal: React.FC<TamperTestModalProps> = ({ onClose }) => {
  const [file, setFile] = useState<File | null>(null);
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const runTamperTest = async () => {
    if (!file || !password) return;

    setLoading(true);
    setResult(null);

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('password', password);

      const res = await fetch('/api/tamper-test', {
        method: 'POST',
        body: formData
      });

      const data = await res.json();
      setResult(data);
    } catch (err: any) {
      setResult({ error: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-sans">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 text-slate-200 shadow-2xl relative space-y-4">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
          <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 text-rose-400 rounded-xl">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-slate-100 text-base">AES-256-GCM Tamper Detection Proof</h3>
            <p className="text-xs text-slate-400">Flips a random bit in the ciphertext and proves auth tag rejection</p>
          </div>
        </div>

        <div className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-400 font-medium mb-1">Select an .ecr File</label>
            <input
              type="file"
              accept=".ecr"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              className="w-full text-slate-300 bg-slate-950 border border-slate-800 rounded p-2 text-xs"
            />
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1">Decryption Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter file password..."
              className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 focus:outline-none"
            />
          </div>

          <button
            onClick={runTamperTest}
            disabled={!file || !password || loading}
            className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg flex items-center justify-center gap-2 transition disabled:opacity-50"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <AlertTriangle className="w-4 h-4" />}
            Corrupt 1 Byte in Ciphertext & Test Authentication
          </button>
        </div>

        {result && (
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs">
            {result.authTagBlocked ? (
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  AUTHENTICATION TAG REJECTION CONFIRMED
                </div>
                <p className="text-slate-300 font-mono">Byte flipped at offset index: {result.byteFlippedIndex}</p>
                <p className="text-rose-400 font-semibold italic">Output Displayed: "{result.errorMessage}"</p>
                <p className="text-slate-400 text-[11px] leading-relaxed pt-1">{result.explanation}</p>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-rose-400 font-bold">
                <XCircle className="w-4 h-4" />
                {result.result || result.error}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
