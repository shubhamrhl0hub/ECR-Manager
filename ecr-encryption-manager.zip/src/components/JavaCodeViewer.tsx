import React, { useState, useEffect } from 'react';
import { FileCode, Download, Copy, Check, Folder, Code2, Coffee } from 'lucide-react';

interface JavaFile {
  path: string;
  name: string;
  content: string;
}

export const JavaCodeViewer: React.FC = () => {
  const [files, setFiles] = useState<JavaFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<JavaFile | null>(null);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/java-sources')
      .then((res) => res.json())
      .then((data) => {
        if (data.files && data.files.length > 0) {
          setFiles(data.files);
          setSelectedFile(data.files[0]);
        }
      })
      .catch((err) => console.error('Failed to load Java sources', err))
      .finally(() => setLoading(false));
  }, []);

  const handleCopy = () => {
    if (!selectedFile) return;
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadProject = () => {
    window.location.href = '/api/download-java-project';
  };

  // Group files by package folder
  const groupedFiles = files.reduce((acc, file) => {
    const dir = file.path.includes('/') ? file.path.substring(0, file.path.lastIndexOf('/')) : 'root';
    if (!acc[dir]) acc[dir] = [];
    acc[dir].push(file);
    return acc;
  }, {} as Record<string, JavaFile[]>);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[700px] text-slate-200">
      {/* Top Bar */}
      <div className="bg-slate-950 px-5 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-lg">
            <Coffee className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-slate-100 text-sm flex items-center gap-2">
              Java 26 High Security ECR Architecture
              <span className="text-xs px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded font-semibold">100% Java 26</span>
            </h2>
            <p className="text-xs text-slate-400">Pristine, production-grade modular codebase across 20+ source files</p>
          </div>
        </div>

        <button
          onClick={handleDownloadProject}
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-2 shadow-lg shadow-amber-500/10 transition"
        >
          <Download className="w-4 h-4" />
          Download Java 26 Project (.zip)
        </button>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* File Tree Sidebar */}
        <div className="w-64 bg-slate-950/80 border-r border-slate-800 overflow-y-auto p-3 space-y-4 text-xs font-mono">
          {loading ? (
            <div className="p-4 text-slate-500">Loading Java source tree...</div>
          ) : (
            (Object.entries(groupedFiles) as [string, JavaFile[]][]).map(([folder, folderFiles]) => (
              <div key={folder} className="space-y-1">
                <div className="flex items-center gap-1.5 text-slate-400 font-semibold px-2 py-1 uppercase tracking-wider text-[11px]">
                  <Folder className="w-3.5 h-3.5 text-amber-400/80" />
                  {folder}
                </div>
                <div className="pl-3 space-y-0.5 border-l border-slate-800 ml-3">
                  {folderFiles.map((file) => (
                    <button
                      key={file.path}
                      onClick={() => setSelectedFile(file)}
                      className={`w-full text-left px-2 py-1.5 rounded transition flex items-center gap-2 ${
                        selectedFile?.path === file.path
                          ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                      }`}
                    >
                      <FileCode className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{file.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Code Content Area */}
        <div className="flex-1 flex flex-col bg-slate-950 font-mono text-xs overflow-hidden">
          {selectedFile ? (
            <>
              <div className="bg-slate-900/90 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
                <span className="text-amber-300 font-semibold flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-amber-400" />
                  src/{selectedFile.path}
                </span>

                <button
                  onClick={handleCopy}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs flex items-center gap-1.5 transition"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copied' : 'Copy Code'}
                </button>
              </div>

              <div className="flex-1 p-4 overflow-auto text-slate-300 leading-relaxed bg-slate-950">
                <pre><code>{selectedFile.content}</code></pre>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-500">
              Select a file from the sidebar to inspect Java source code.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
