/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Terminal, Coffee, Binary, Download, ShieldCheck, Github, ExternalLink } from 'lucide-react';
import { TerminalCUI } from './components/TerminalCUI';
import { JavaCodeViewer } from './components/JavaCodeViewer';
import { BinaryInspector } from './components/BinaryInspector';
import { TamperTestModal } from './components/TamperTestModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<'terminal' | 'java' | 'binary'>('terminal');
  const [showTamperModal, setShowTamperModal] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Navigation Header */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl shadow-lg shadow-emerald-500/5">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-slate-100 text-base sm:text-lg flex items-center gap-2">
                ECR Encryption Manager
                <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full font-mono font-semibold">
                  Java 26 Architecture
                </span>
              </h1>
              <p className="text-xs text-slate-400">AES-256-GCM • PBKDF2-HMAC-SHA512 • Tamper Resistance • Zeroization Memory</p>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-1 sm:gap-2 bg-slate-950 p-1 border border-slate-800 rounded-xl text-xs font-medium">
            <button
              onClick={() => setActiveTab('terminal')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
                activeTab === 'terminal' ? 'bg-emerald-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Interactive</span> Terminal CUI
            </button>

            <button
              onClick={() => setActiveTab('java')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
                activeTab === 'java' ? 'bg-amber-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Coffee className="w-3.5 h-3.5" />
              Java 26 Source Code
            </button>

            <button
              onClick={() => setActiveTab('binary')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
                activeTab === 'binary' ? 'bg-cyan-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Binary className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Binary Layout</span> Spec
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col">
        {activeTab === 'terminal' && (
          <TerminalCUI
            onOpenJavaSources={() => setActiveTab('java')}
            onOpenTamperTest={() => setShowTamperModal(true)}
          />
        )}

        {activeTab === 'java' && <JavaCodeViewer />}

        {activeTab === 'binary' && <BinaryInspector />}
      </main>

      {/* Footer Bar */}
      <footer className="border-t border-slate-900 bg-slate-950 text-slate-500 py-3 text-xs">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>ECR Encryption Manager • 100% Java 26 Cryptographic Standard • Developer: $HUBHAM</span>
          <div className="flex items-center gap-4">
            <a
              href="/api/download-java-project"
              className="text-amber-400 hover:underline flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" /> Download Complete Java 26 ZIP
            </a>
          </div>
        </div>
      </footer>

      {showTamperModal && <TamperTestModal onClose={() => setShowTamperModal(false)} />}
    </div>
  );
}
