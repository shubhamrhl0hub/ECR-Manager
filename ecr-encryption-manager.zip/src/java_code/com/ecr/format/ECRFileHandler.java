package com.ecr.format;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Handles reading and writing binary .ecr files.
 */
public final class ECRFileHandler {

    public record ECRContainer(ECRHeader header, ECRMetadata metadata, byte[] ciphertext) {}

    private ECRFileHandler() {
        // Utility
    }

    /**
     * Packs header, metadata, and ciphertext into an .ecr file.
     */
    public static void writeEcrFile(Path outputPath, ECRHeader header, byte[] metadataBytes, byte[] ciphertext) throws IOException {
        try (DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(outputPath)))) {
            byte[] headerBytes = header.toBytes();
            dos.write(headerBytes);
            dos.write(metadataBytes);
            dos.write(ciphertext);
            dos.flush();
        }
    }

    /**
     * Reads and parses an .ecr file container.
     */
    public static ECRContainer readEcrFile(Path inputPath) throws IOException {
        long fileSize = Files.size(inputPath);
        if (fileSize < ECRHeader.HEADER_FIXED_SIZE) {
            throw new IOException("File too small to be a valid ECR container.");
        }

        try (DataInputStream dis = new DataInputStream(new BufferedInputStream(Files.newInputStream(inputPath)))) {
            byte[] headerBytes = new byte[ECRHeader.HEADER_FIXED_SIZE];
            dis.readFully(headerBytes);
            ECRHeader header = ECRHeader.parse(headerBytes);

            if (header.metadataLength() < 0 || header.metadataLength() > 10_000_000) {
                throw new IOException("Invalid metadata length in header.");
            }

            byte[] metadataBytes = new byte[header.metadataLength()];
            dis.readFully(metadataBytes);
            ECRMetadata metadata = ECRMetadata.deserialize(metadataBytes);

            long rawCiphertextLen = fileSize - ECRHeader.HEADER_FIXED_SIZE - header.metadataLength();
            if (rawCiphertextLen <= 0 || rawCiphertextLen > 100_000_000) {
                throw new IOException("Ciphertext payload is invalid, missing, or too large for in-memory buffer reading.");
            }
            int ciphertextLength = (int) rawCiphertextLen;

            byte[] ciphertext = new byte[ciphertextLength];
            dis.readFully(ciphertext);

            return new ECRContainer(header, metadata, ciphertext);
        }
    }
}
