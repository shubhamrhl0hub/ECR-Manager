package com.ecr.format;

/**
 * Defines constants and structural specification for the .ecr custom file format.
 */
public final class ECRFileStructure {

    public static final byte[] MAGIC_HEADER = new byte[]{(byte) 'E', (byte) 'C', (byte) 'R', (byte) '1'};
    public static final short CURRENT_VERSION = 1;
    public static final byte KDF_PBKDF2_SHA512 = 1;
    public static final byte KDF_ARGON2ID = 2;

    public static final String FILE_EXTENSION = ".ecr";

    private ECRFileStructure() {
        // Constants class
    }
}
