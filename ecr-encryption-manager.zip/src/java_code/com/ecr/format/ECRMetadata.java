package com.ecr.format;

import java.nio.charset.StandardCharsets;

/**
 * Embedded file metadata (unencrypted metadata payload included in AAD authentication).
 * Supports optional Ed25519 digital signature for file authenticity verification.
 */
public record ECRMetadata(
        String originalFilename,
        long creationTimestamp,
        long uncompressedSize,
        String sha256Checksum,
        String digitalSignature,  // Base64 encoded signature (optional)
        String signerPublicKey    // Base64 encoded public key (optional)
) {

    // Overloaded constructor for v1 metadata compatibility
    public ECRMetadata(String originalFilename, long creationTimestamp, long uncompressedSize, String sha256Checksum) {
        this(originalFilename, creationTimestamp, uncompressedSize, sha256Checksum, null, null);
    }

    public boolean hasDigitalSignature() {
        return digitalSignature != null && !digitalSignature.isBlank() &&
               signerPublicKey != null && !signerPublicKey.isBlank();
    }

    public byte[] serialize() {
        StringBuilder json = new StringBuilder();
        json.append(String.format(
                "{\"file\":\"%s\",\"timestamp\":%d,\"size\":%d,\"sha256\":\"%s\"",
                escapeJson(originalFilename),
                creationTimestamp,
                uncompressedSize,
                sha256Checksum
        ));

        if (digitalSignature != null && !digitalSignature.isBlank()) {
            json.append(String.format(",\"sig\":\"%s\"", escapeJson(digitalSignature)));
        }
        if (signerPublicKey != null && !signerPublicKey.isBlank()) {
            json.append(String.format(",\"pubKey\":\"%s\"", escapeJson(signerPublicKey)));
        }

        json.append("}");
        return json.toString().getBytes(StandardCharsets.UTF_8);
    }

    public static ECRMetadata deserialize(byte[] bytes) {
        String json = new String(bytes, StandardCharsets.UTF_8);
        String filename = extractValue(json, "file");
        
        String tsStr = extractValue(json, "timestamp");
        long timestamp = tsStr.isEmpty() ? 0L : Long.parseLong(tsStr);

        String szStr = extractValue(json, "size");
        long size = szStr.isEmpty() ? 0L : Long.parseLong(szStr);

        String checksum = extractValue(json, "sha256");
        String sig = extractValue(json, "sig");
        String pubKey = extractValue(json, "pubKey");

        return new ECRMetadata(
                filename,
                timestamp,
                size,
                checksum,
                sig.isEmpty() ? null : sig,
                pubKey.isEmpty() ? null : pubKey
        );
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String extractValue(String json, String key) {
        String pattern = "\"" + key + "\":";
        int start = json.indexOf(pattern);
        if (start == -1) return "";
        start += pattern.length();
        if (start < json.length() && json.charAt(start) == '"') {
            start++;
            int end = json.indexOf('"', start);
            if (end == -1) return "";
            return json.substring(start, end);
        } else {
            int end = start;
            while (end < json.length() && (Character.isDigit(json.charAt(end)) || json.charAt(end) == '-')) {
                end++;
            }
            return json.substring(start, end);
        }
    }
}
