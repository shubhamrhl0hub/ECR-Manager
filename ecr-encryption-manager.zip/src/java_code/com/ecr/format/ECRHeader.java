package com.ecr.format;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Binary layout header for .ecr files.
 *
 * Structure:
 * - Magic Header: 4 bytes ("ECR1" = 0x45, 0x43, 0x52, 0x31)
 * - Version: 2 bytes (short)
 * - KDF Algorithm ID: 1 byte (1 = PBKDF2-HMAC-SHA512)
 * - KDF Iterations: 4 bytes (int)
 * - Salt: 32 bytes
 * - Nonce (IV): 12 bytes
 * - Metadata Length: 4 bytes (int)
 */
public record ECRHeader(
        byte[] magic,
        short version,
        byte kdfAlgId,
        int kdfIterations,
        byte[] salt,
        byte[] nonce,
        int metadataLength
) {

    public static final int HEADER_FIXED_SIZE = 4 + 2 + 1 + 4 + 32 + 12 + 4; // 59 bytes

    public byte[] toBytes() {
        ByteBuffer bb = ByteBuffer.allocate(HEADER_FIXED_SIZE);
        bb.order(ByteOrder.BIG_ENDIAN);
        bb.put(magic);
        bb.putShort(version);
        bb.put(kdfAlgId);
        bb.putInt(kdfIterations);
        bb.put(salt);
        bb.put(nonce);
        bb.putInt(metadataLength);
        return bb.array();
    }

    public static ECRHeader parse(byte[] bytes) {
        if (bytes == null || bytes.length < HEADER_FIXED_SIZE) {
            throw new IllegalArgumentException("Header buffer too small.");
        }
        ByteBuffer bb = ByteBuffer.wrap(bytes);
        bb.order(ByteOrder.BIG_ENDIAN);

        byte[] magic = new byte[4];
        bb.get(magic);
        short version = bb.getShort();
        byte kdfAlgId = bb.get();
        int kdfIterations = bb.getInt();

        byte[] salt = new byte[32];
        bb.get(salt);

        byte[] nonce = new byte[12];
        bb.get(nonce);

        int metadataLength = bb.getInt();

        return new ECRHeader(magic, version, kdfAlgId, kdfIterations, salt, nonce, metadataLength);
    }
}
