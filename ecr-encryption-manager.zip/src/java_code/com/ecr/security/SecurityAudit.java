package com.ecr.security;

import com.ecr.config.SecureConfigManager;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Thread-safe, secure audit logger for ECR Encryption Manager.
 * 
 * Features:
 * - Never records passwords, secret key material, or sensitive raw buffers.
 * - Automatic log file rotation when file size exceeds configuration limit.
 * - In-memory ring buffer of recent audit entries for real-time monitoring.
 * - Safe exception handling: logging errors NEVER interrupt cryptographic operations.
 */
public final class SecurityAudit {

    private static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss 'UTC'");
    private static final int IN_MEMORY_LOG_CAPACITY = 100;

    private static final List<String> RECENT_LOGS = Collections.synchronizedList(new ArrayList<>());

    // Sanitization patterns to strip any potential sensitive data
    private static final Pattern SENSITIVE_KEY_PATTERN = Pattern.compile("(?i)(password|secret|key|token|auth)[=:]\\s*\\S+");

    private SecurityAudit() {
        // Utility
    }

    /**
     * Legacy single-string event logger compatibility wrapper.
     */
    public static void logEvent(String eventType, String detail) {
        logEvent(eventType, "INFO", detail);
    }

    /**
     * Logs a security audit event with explicit status and details.
     */
    public static synchronized void logEvent(String eventType, String status, String detail) {
        String timestamp = ZonedDateTime.now(ZoneOffset.UTC).format(TIMESTAMP_FORMATTER);
        String safeDetail = sanitize(detail);
        String entry = String.format("[%s] [%-18s] [%-7s] - %s", timestamp, eventType, status, safeDetail);

        // 1. Terminal / Console output
        System.out.println(entry);

        // 2. In-memory buffer
        synchronized (RECENT_LOGS) {
            if (RECENT_LOGS.size() >= IN_MEMORY_LOG_CAPACITY) {
                RECENT_LOGS.remove(0);
            }
            RECENT_LOGS.add(entry);
        }

        // 3. Persistent log file with rotation
        try {
            SecureConfigManager.ConfigSnapshot cfg = SecureConfigManager.getInstance().getConfig();
            String logFileName = cfg.auditLogFilePath();
            Path logPath = Paths.get(logFileName);

            // Check if rotation is needed
            long maxBytes = (long) cfg.maxLogSizeMB() * 1024 * 1024;
            if (Files.exists(logPath) && Files.size(logPath) >= maxBytes) {
                rotateLogs(logPath, cfg.maxLogFiles());
            }

            // Append log entry safely
            try (BufferedWriter writer = Files.newBufferedWriter(logPath, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
                writer.write(entry);
                writer.newLine();
                writer.flush();
            }
        } catch (Throwable t) {
            // Logging failure must NEVER crash primary operations
            System.err.println("⚠ AUDIT LOGGER WARNING: Could not write to log file: " + t.getMessage());
        }
    }

    /**
     * Rotates audit log files (e.g., ecr-audit.log -> ecr-audit.log.1, etc.)
     */
    private static void rotateLogs(Path mainLogPath, int maxFiles) {
        try {
            String basePath = mainLogPath.toAbsolutePath().toString();

            // Delete oldest log file if exists
            Path oldestPath = Paths.get(basePath + "." + maxFiles);
            Files.deleteIfExists(oldestPath);

            // Shift older log files up by one
            for (int i = maxFiles - 1; i >= 1; i--) {
                Path src = Paths.get(basePath + "." + i);
                Path dest = Paths.get(basePath + "." + (i + 1));
                if (Files.exists(src)) {
                    Files.move(src, dest, StandardCopyOption.REPLACE_EXISTING);
                }
            }

            // Shift current main log to .1
            Path dest = Paths.get(basePath + ".1");
            Files.move(mainLogPath, dest, StandardCopyOption.REPLACE_EXISTING);

        } catch (IOException e) {
            System.err.println("⚠ AUDIT LOGGER WARNING: Log rotation encountered error: " + e.getMessage());
        }
    }

    /**
     * Sanitizes input strings to strip potential sensitive key/password patterns.
     */
    private static String sanitize(String input) {
        if (input == null || input.isBlank()) return "";
        return SENSITIVE_KEY_PATTERN.matcher(input).replaceAll("$1=[REDACTED]");
    }

    /**
     * Retrieves recent in-memory log entries.
     */
    public static List<String> getRecentLogs() {
        synchronized (RECENT_LOGS) {
            return new ArrayList<>(RECENT_LOGS);
        }
    }
}
