package com.ecr.security;

import java.security.MessageDigest;

/**
 * Constant-time byte array comparison to protect against timing side-channel attacks.
 */
public final class ConstantTime {

    private ConstantTime() {
        // Utility
    }

    /**
     * Constant-time byte array comparison.
     *
     * @param a first byte array
     * @param b second byte array
     * @return true if equal in value and length
     */
    public static boolean equals(byte[] a, byte[] b) {
        if (a == null || b == null) {
            return a == b;
        }
        return MessageDigest.isEqual(a, b);
    }
}
