package com.ecr.security;

import com.ecr.crypto.MemoryCleaner;

/**
 * Ensures memory scrubbing for keys, passwords, and sensitive byte buffers.
 */
public final class Zeroization {

    private Zeroization() {
        // Utility
    }

    public static void wipe(byte[] buffer) {
        MemoryCleaner.clear(buffer);
    }

    public static void wipe(char[] password) {
        MemoryCleaner.clear(password);
    }
}
