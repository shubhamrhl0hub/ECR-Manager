package com.ecr.config;

import com.ecr.security.SecurityAudit;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * Thread-safe, secure configuration manager for ECR Encryption Manager.
 * 
 * Manages operational parameters with strict bounds validation and fallback to secure defaults.
 * Guarantees that secrets (passwords, keys) are NEVER accepted or persisted.
 */
public final class SecureConfigManager {

    // Default Configuration Constants
    public static final int DEFAULT_CHUNK_SIZE_BYTES = 64 * 1024; // 64 KB
    public static final int MIN_CHUNK_SIZE_BYTES = 4 * 1024;     // 4 KB
    public static final int MAX_CHUNK_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB

    public static final int DEFAULT_KDF_ITERATIONS = 210000;
    public static final int MIN_KDF_ITERATIONS = 100000;
    public static final int MAX_KDF_ITERATIONS = 10000000;

    public static final int DEFAULT_MAX_LOG_SIZE_MB = 5;
    public static final int MIN_MAX_LOG_SIZE_MB = 1;
    public static final int MAX_MAX_LOG_SIZE_MB = 100;

    public static final int DEFAULT_MAX_LOG_FILES = 5;
    public static final int MIN_MAX_LOG_FILES = 1;
    public static final int MAX_MAX_LOG_FILES = 20;

    private static final String DEFAULT_CONFIG_FILENAME = "ecr-config.properties";

    private static final SecureConfigManager INSTANCE = new SecureConfigManager();

    private volatile ConfigSnapshot currentConfig;

    public record ConfigSnapshot(
            int chunkSizeBytes,
            int kdfIterations,
            boolean showProgress,
            boolean enableDigitalSignatures,
            int maxLogSizeMB,
            int maxLogFiles,
            String auditLogFilePath,
            int minSupportedVersion,
            boolean allowLegacyVersions
    ) {}

    private SecureConfigManager() {
        this.currentConfig = createDefaultSnapshot();
    }

    public static SecureConfigManager getInstance() {
        return INSTANCE;
    }

    public static ConfigSnapshot createDefaultSnapshot() {
        return new ConfigSnapshot(
                DEFAULT_CHUNK_SIZE_BYTES,
                DEFAULT_KDF_ITERATIONS,
                true,
                true,
                DEFAULT_MAX_LOG_SIZE_MB,
                DEFAULT_MAX_LOG_FILES,
                "ecr-audit.log",
                1,
                true
        );
    }

    public ConfigSnapshot getConfig() {
        return currentConfig;
    }

    /**
     * Safely loads configuration from file path. Falls back to secure defaults if missing or invalid.
     */
    public synchronized void loadConfig(String filePathStr) {
        Path path = Paths.get(filePathStr != null && !filePathStr.isBlank() ? filePathStr : DEFAULT_CONFIG_FILENAME);
        if (!Files.exists(path)) {
            SecurityAudit.logEvent("CONFIG_LOAD", "INFO", "Configuration file not found at " + path.getFileName() + ". Using secure defaults.");
            saveDefaultConfig(path);
            return;
        }

        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            props.load(in);
            SecurityAudit.logEvent("CONFIG_LOAD", "INFO", "Loaded configuration file from " + path.getFileName());
        } catch (Exception e) {
            SecurityAudit.logEvent("CONFIG_LOAD_FAILURE", "FAILED", "Failed to read configuration file: " + e.getMessage() + ". Reverting to secure defaults.");
            this.currentConfig = createDefaultSnapshot();
            return;
        }

        // Validate and apply values defensively
        int chunkSize = validateInt(props.getProperty("chunkSizeBytes"), MIN_CHUNK_SIZE_BYTES, MAX_CHUNK_SIZE_BYTES, DEFAULT_CHUNK_SIZE_BYTES, "chunkSizeBytes");
        int kdfIters = validateInt(props.getProperty("kdfIterations"), MIN_KDF_ITERATIONS, MAX_KDF_ITERATIONS, DEFAULT_KDF_ITERATIONS, "kdfIterations");
        boolean progress = validateBoolean(props.getProperty("showProgress"), true, "showProgress");
        boolean sigs = validateBoolean(props.getProperty("enableDigitalSignatures"), true, "enableDigitalSignatures");
        int maxLogMB = validateInt(props.getProperty("maxLogSizeMB"), MIN_MAX_LOG_SIZE_MB, MAX_MAX_LOG_SIZE_MB, DEFAULT_MAX_LOG_SIZE_MB, "maxLogSizeMB");
        int maxLogs = validateInt(props.getProperty("maxLogFiles"), MIN_MAX_LOG_FILES, MAX_MAX_LOG_FILES, DEFAULT_MAX_LOG_FILES, "maxLogFiles");
        String logPath = validateString(props.getProperty("auditLogFilePath"), "ecr-audit.log", "auditLogFilePath");
        int minVer = validateInt(props.getProperty("minSupportedVersion"), 1, 2, 1, "minSupportedVersion");
        boolean legacy = validateBoolean(props.getProperty("allowLegacyVersions"), true, "allowLegacyVersions");

        this.currentConfig = new ConfigSnapshot(chunkSize, kdfIters, progress, sigs, maxLogMB, maxLogs, logPath, minVer, legacy);
        SecurityAudit.logEvent("CONFIG_VERIFIED", "SUCCESS", "Secure configuration active: [Chunk: " + (chunkSize / 1024) + "KB, PBKDF2: " + kdfIters + " iters, LogMax: " + maxLogMB + "MB]");
    }

    public synchronized void saveDefaultConfig(Path path) {
        try {
            Properties props = new Properties();
            ConfigSnapshot def = createDefaultSnapshot();
            props.setProperty("chunkSizeBytes", String.valueOf(def.chunkSizeBytes()));
            props.setProperty("kdfIterations", String.valueOf(def.kdfIterations()));
            props.setProperty("showProgress", String.valueOf(def.showProgress()));
            props.setProperty("enableDigitalSignatures", String.valueOf(def.enableDigitalSignatures()));
            props.setProperty("maxLogSizeMB", String.valueOf(def.maxLogSizeMB()));
            props.setProperty("maxLogFiles", String.valueOf(def.maxLogFiles()));
            props.setProperty("auditLogFilePath", def.auditLogFilePath());
            props.setProperty("minSupportedVersion", String.valueOf(def.minSupportedVersion()));
            props.setProperty("allowLegacyVersions", String.valueOf(def.allowLegacyVersions()));

            try (OutputStream out = Files.newOutputStream(path)) {
                props.store(out, "ECR Encryption Manager v2.1 Secure Configuration File\nDO NOT STORE SECRETS OR PASSWORDS IN THIS FILE");
            }
            SecurityAudit.logEvent("CONFIG_CREATED", "SUCCESS", "Generated default configuration file at " + path.getFileName());
        } catch (Exception e) {
            SecurityAudit.logEvent("CONFIG_CREATE_ERROR", "FAILED", "Could not write default configuration file: " + e.getMessage());
        }
    }

    private static int validateInt(String raw, int min, int max, int defaultValue, String paramName) {
        if (raw == null || raw.isBlank()) return defaultValue;
        try {
            int val = Integer.parseInt(raw.trim());
            if (val < min || val > max) {
                SecurityAudit.logEvent("CONFIG_VALIDATION_WARN", "FAILED", String.format("Parameter '%s' value %d out of bounds [%d-%d]. Fallback to default %d.", paramName, val, min, max, defaultValue));
                return defaultValue;
            }
            return val;
        } catch (NumberFormatException e) {
            SecurityAudit.logEvent("CONFIG_VALIDATION_WARN", "FAILED", String.format("Parameter '%s' has invalid integer format '%s'. Fallback to default %d.", paramName, raw, defaultValue));
            return defaultValue;
        }
    }

    private static boolean validateBoolean(String raw, boolean defaultValue, String paramName) {
        if (raw == null || raw.isBlank()) return defaultValue;
        String trimmed = raw.trim().toLowerCase();
        if (trimmed.equals("true") || trimmed.equals("yes") || trimmed.equals("1")) return true;
        if (trimmed.equals("false") || trimmed.equals("no") || trimmed.equals("0")) return false;
        SecurityAudit.logEvent("CONFIG_VALIDATION_WARN", "FAILED", String.format("Parameter '%s' invalid boolean '%s'. Fallback to %b.", paramName, raw, defaultValue));
        return defaultValue;
    }

    private static String validateString(String raw, String defaultValue, String paramName) {
        if (raw == null || raw.isBlank()) return defaultValue;
        String sanitized = raw.trim();
        if (sanitized.contains("..") || sanitized.contains("\0")) {
            SecurityAudit.logEvent("CONFIG_VALIDATION_WARN", "FAILED", String.format("Parameter '%s' path traversal or unsafe char detected. Fallback to %s.", paramName, defaultValue));
            return defaultValue;
        }
        return sanitized;
    }
}
