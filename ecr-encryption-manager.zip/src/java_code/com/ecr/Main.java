package com.ecr;

import com.ecr.cli.TerminalInterface;
import com.ecr.config.SecureConfigManager;
import com.ecr.security.SecurityAudit;

/**
 * Main entry point for the Java 26 ECR High Security Terminal Encryption Manager v2.1.
 *
 * Compile: javac -d bin $(find src -name "*.java")
 * Run:     java -cp bin com.ecr.Main
 */
public class Main {

    public static void main(String[] args) {
        // Record startup in security audit log
        SecurityAudit.logEvent("APP_STARTUP", "SUCCESS", "Starting ECR High Security Terminal Encryption Manager v2.1 (Java 26)...");

        // Verify and load secure application configuration
        SecureConfigManager.getInstance().loadConfig("ecr-config.properties");

        // Launch CLI Terminal Interface
        TerminalInterface cli = new TerminalInterface();
        cli.start();
    }
}
