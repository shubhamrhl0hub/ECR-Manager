package com.ecr.manager;

/**
 * Interface for reporting file operation progress.
 */
public interface ProgressListener {

    void onProgress(long bytesProcessed, long totalBytes, String stage);

    void onComplete(String message);

    void onError(String errorMessage);
}
