package com.ecr.manager;

import com.ecr.config.SecureConfigManager;
import com.ecr.crypto.*;
import com.ecr.format.*;
import com.ecr.security.*;
import com.ecr.validation.*;

import javax.crypto.AEADBadTagException;
import java.io.*;
import java.nio.file.*;
import java.time.Instant;
import java.util.Base64;

/**
 * High-performance, streaming orchestration manager v2.1 for ECR files.
 * Provides AES-256-GCM chunked streaming, optional digital signatures (Ed25519),
 * tamper-resistant payload verification, zeroized key management, and secure configuration binding.
 */
public class ECREncryptionManager {

    /**
     * Converts a .zip archive into an encrypted .ecr container using streaming I/O.
     */
    public void encryptZipToEcr(Path zipPath, Path ecrPath, char[] password, ProgressListener listener) throws Exception {
        encryptZipToEcrSigned(zipPath, ecrPath, password, null, null, listener);
    }

    /**
     * Converts a .zip archive into an encrypted .ecr container with optional digital signature.
     */
    public void encryptZipToEcrSigned(
            Path zipPath,
            Path ecrPath,
            char[] password,
            String signingPrivateKeyBase64,
            String signerPublicKeyBase64,
            ProgressListener listener
    ) throws Exception {
        SecureConfigManager.ConfigSnapshot cfg = SecureConfigManager.getInstance().getConfig();
        SecurityAudit.logEvent("ENCRYPT_START", "INFO", "Initiating encryption for " + zipPath.getFileName() + " -> " + ecrPath.getFileName());

        Path tempEcr = null;
        try {
            if (listener != null) listener.onProgress(0, 100, "Validating input ZIP file...");
            FileFormatValidator.validateInputFile(zipPath);

            long totalZipSize = Files.size(zipPath);
            String sha256Checksum = IntegrityValidator.computeFileSHA256(zipPath);

            String sigBase64 = null;
            if (cfg.enableDigitalSignatures() && signingPrivateKeyBase64 != null && !signingPrivateKeyBase64.isBlank()) {
                if (listener != null) listener.onProgress(10, 100, "Generating Ed25519 digital signature...");
                byte[] fileHashBytes = sha256Checksum.getBytes();
                byte[] sigBytes = DigitalSignature.sign(fileHashBytes, signingPrivateKeyBase64);
                sigBase64 = Base64.getEncoder().encodeToString(sigBytes);
                SecurityAudit.logEvent("DIGITAL_SIGNATURE", "SUCCESS", "Generated Ed25519 signature for " + zipPath.getFileName());
            }

            if (listener != null) listener.onProgress(20, 100, "Generating 256-bit salt & nonce...");
            byte[] salt = SecureRandomProvider.generateSalt();
            byte[] nonce = SecureRandomProvider.generateNonce();

            int kdfIterations = cfg.kdfIterations();
            if (listener != null) listener.onProgress(35, 100, "Deriving encryption key via PBKDF2-HMAC-SHA512 (" + kdfIterations + " iters)...");
            byte[] derivedKey = KeyDerivation.deriveKey(password, salt, kdfIterations);

            try {
                ECRMetadata metadata = new ECRMetadata(
                        zipPath.getFileName().toString(),
                        Instant.now().getEpochSecond(),
                        totalZipSize,
                        sha256Checksum,
                        sigBase64,
                        signerPublicKeyBase64
                );
                byte[] metadataBytes = metadata.serialize();

                ECRHeader header = new ECRHeader(
                        ECRFileStructure.MAGIC_HEADER,
                        ECRFileStructure.CURRENT_VERSION,
                        ECRFileStructure.KDF_PBKDF2_SHA512,
                        kdfIterations,
                        salt,
                        nonce,
                        metadataBytes.length
                );

                byte[] aad = header.toBytes();

                if (listener != null) listener.onProgress(50, 100, "Encrypting archive stream via AES-256-GCM...");
                tempEcr = createTempFileNear(ecrPath, "ecr_enc_", ".tmp");

                try (
                    InputStream zipStream = new BufferedInputStream(Files.newInputStream(zipPath));
                    DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tempEcr)))
                ) {
                    dos.write(header.toBytes());
                    dos.write(metadataBytes);
                    dos.flush();

                    StreamingCipher.encryptStream(
                            zipStream,
                            dos,
                            derivedKey,
                            nonce,
                            aad,
                            totalZipSize,
                            listener
                    );
                }

                safeMoveFile(tempEcr, ecrPath);
            } finally {
                Zeroization.wipe(derivedKey);
            }

            // Wipe credentials
            Zeroization.wipe(password);

            SecurityAudit.logEvent("ENCRYPT_SUCCESS", "SUCCESS", "Encrypted " + zipPath.getFileName() + " -> " + ecrPath.getFileName() + (sigBase64 != null ? " [DIGITALLY SIGNED]" : ""));
            if (listener != null) listener.onComplete("Encryption completed successfully.\n\nYour ZIP file has been encrypted into an ECR file with no detected errors.");

        } catch (Exception e) {
            if (tempEcr != null) {
                try { Files.deleteIfExists(tempEcr); } catch (IOException ignored) {}
            }
            Zeroization.wipe(password);
            SecurityAudit.logEvent("ENCRYPT_FAILURE", "FAILED", "Encryption failed for " + zipPath.getFileName() + ": " + e.getMessage());
            if (listener != null) listener.onError("Encryption failed: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Decrypts an .ecr container back to its original .zip archive with streaming & signature verification.
     */
    public void decryptEcrToZip(Path ecrPath, Path zipPath, char[] password, ProgressListener listener) throws Exception {
        SecurityAudit.logEvent("DECRYPT_START", "INFO", "Initiating decryption for " + ecrPath.getFileName() + " -> " + zipPath.getFileName());
        Path tempZip = null;
        try {
            if (listener != null) listener.onProgress(5, 100, "Parsing ECR container header & metadata...");
            FileFormatValidator.validateInputFile(ecrPath);

            long totalEcrSize = Files.size(ecrPath);
            if (totalEcrSize < ECRHeader.HEADER_FIXED_SIZE) {
                SecurityAudit.logEvent("VALIDATION_FAILURE", "FAILED", "File " + ecrPath.getFileName() + " below minimum header size.");
                throw new Exception("Invalid, corrupted, tampered, or unsupported ECR file.");
            }

            ECRHeader header;
            ECRMetadata metadata;

            try (DataInputStream dis = new DataInputStream(new BufferedInputStream(Files.newInputStream(ecrPath)))) {
                byte[] headerBytes = new byte[ECRHeader.HEADER_FIXED_SIZE];
                dis.readFully(headerBytes);
                header = ECRHeader.parse(headerBytes);

                HeaderValidator.validateHeader(header);

                byte[] metadataBytes = new byte[header.metadataLength()];
                dis.readFully(metadataBytes);
                metadata = ECRMetadata.deserialize(metadataBytes);
            }

            // Verify optional Digital Signature prior to decryption
            if (metadata.hasDigitalSignature()) {
                if (listener != null) listener.onProgress(20, 100, "Verifying Ed25519 digital signature authenticity...");
                byte[] expectedHashBytes = metadata.sha256Checksum().getBytes();
                byte[] sigBytes = Base64.getDecoder().decode(metadata.digitalSignature());
                boolean authentic = DigitalSignature.verify(expectedHashBytes, sigBytes, metadata.signerPublicKey());
                if (!authentic) {
                    SecurityAudit.logEvent("SIGNATURE_VERIFY", "FAILED", "Digital signature verification failed for " + ecrPath.getFileName());
                    throw new Exception("Digital Signature Verification Failed: Authenticity of file source cannot be confirmed.");
                }
                SecurityAudit.logEvent("SIGNATURE_VERIFY", "SUCCESS", "Digital signature verified authentic for " + ecrPath.getFileName());
            }

            if (listener != null) listener.onProgress(35, 100, "Deriving 256-bit key from salt and password...");
            byte[] derivedKey = KeyDerivation.deriveKey(password, header.salt(), header.kdfIterations());

            try {
                byte[] aad = header.toBytes();
                long ciphertextLength = totalEcrSize - ECRHeader.HEADER_FIXED_SIZE - header.metadataLength();

                tempZip = createTempFileNear(zipPath, "ecr_dec_", ".tmp");

                if (listener != null) listener.onProgress(50, 100, "Decrypting ciphertext stream & validating tag...");

                try (
                    InputStream ecrStream = new BufferedInputStream(Files.newInputStream(ecrPath));
                    OutputStream zipStream = new BufferedOutputStream(Files.newOutputStream(tempZip))
                ) {
                    long skipBytes = ECRHeader.HEADER_FIXED_SIZE + header.metadataLength();
                    long remainingToSkip = skipBytes;
                    while (remainingToSkip > 0) {
                        long skipped = ecrStream.skip(remainingToSkip);
                        if (skipped <= 0) {
                            if (ecrStream.read() == -1) {
                                throw new Exception("Truncated ECR file header/metadata.");
                            }
                            remainingToSkip--;
                        } else {
                            remainingToSkip -= skipped;
                        }
                    }

                    StreamingCipher.decryptStream(
                            ecrStream,
                            zipStream,
                            derivedKey,
                            header.nonce(),
                            aad,
                            ciphertextLength,
                            listener
                    );
                } catch (AEADBadTagException e) {
                    SecurityAudit.logEvent("AUTHENTICATION_TAG", "FAILED", "AES-256-GCM auth tag mismatch on " + ecrPath.getFileName());
                    throw new Exception("Invalid, corrupted, tampered, or unsupported ECR file.");
                }

                if (listener != null) listener.onProgress(90, 100, "Verifying decrypted archive SHA-256 integrity...");
                String actualSHA256 = IntegrityValidator.computeFileSHA256(tempZip);
                if (!actualSHA256.equalsIgnoreCase(metadata.sha256Checksum())) {
                    SecurityAudit.logEvent("INTEGRITY_CHECK", "FAILED", "SHA-256 payload checksum mismatch on " + ecrPath.getFileName());
                    throw new Exception("Invalid, corrupted, tampered, or unsupported ECR file.");
                }

                safeMoveFile(tempZip, zipPath);
            } finally {
                Zeroization.wipe(derivedKey);
            }

            Zeroization.wipe(password);

            SecurityAudit.logEvent("DECRYPT_SUCCESS", "SUCCESS", "Decrypted " + ecrPath.getFileName() + " -> " + zipPath.getFileName());
            if (listener != null) listener.onComplete("Decryption completed successfully.\n\nYour ECR file has been restored to the original ZIP file with no detected errors.");

        } catch (Exception e) {
            if (tempZip != null && Files.exists(tempZip)) {
                Files.deleteIfExists(tempZip);
            }
            Zeroization.wipe(password);
            SecurityAudit.logEvent("DECRYPT_FAILURE", "FAILED", "Decryption failed for " + ecrPath.getFileName() + ": " + e.getMessage());
            if (listener != null) listener.onError("Decryption failed: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Verifies file headers, magic structure, and metadata validity without password.
     */
    public boolean verifyEcrFile(Path ecrPath) throws Exception {
        try {
            SecurityAudit.logEvent("VERIFY_FILE", "INFO", "Verifying file structure for " + ecrPath.getFileName());
            ECRFileHandler.ECRContainer container = ECRFileHandler.readEcrFile(ecrPath);
            HeaderValidator.validateHeader(container.header());
            SecurityAudit.logEvent("VERIFY_FILE", "SUCCESS", "File structure valid for " + ecrPath.getFileName());
            return true;
        } catch (Exception e) {
            SecurityAudit.logEvent("VERIFY_FILE", "FAILED", "File verification failed for " + ecrPath.getFileName() + ": " + e.getMessage());
            System.err.println("«Invalid, corrupted, tampered, or unsupported ECR file.»");
            return false;
        }
    }

    private static Path createTempFileNear(Path targetPath, String prefix, String suffix) throws IOException {
        Path parent = targetPath.toAbsolutePath().getParent();
        if (parent != null && Files.exists(parent) && Files.isWritable(parent)) {
            try {
                return Files.createTempFile(parent, prefix, suffix);
            } catch (IOException ignored) {
                // Fall back to system temp directory
            }
        }
        return Files.createTempFile(prefix, suffix);
    }

    private static void safeMoveFile(Path source, Path target) throws IOException {
        try {
            Files.move(source, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (FileSystemException e) {
            try {
                Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException copyEx) {
                Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
                Files.deleteIfExists(source);
            }
        }
    }
}
