package com.ecr.crypto;

import com.ecr.manager.ProgressListener;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * High-performance streaming AES-256-GCM cipher processor.
 * Processes multi-GB input archives using 64KB chunked memory buffers
 * to maintain low and constant RAM overhead with real-time progress reporting.
 */
public final class StreamingCipher {

    public static final int BUFFER_SIZE = 64 * 1024; // 64 KB chunk buffer
    public static final int GCM_TAG_LENGTH_BITS = 128;
    public static final int GCM_TAG_LENGTH_BYTES = 16;

    private StreamingCipher() {
        // Utility
    }

    /**
     * Encrypts an input stream to an output stream in 64KB chunks.
     */
    public static void encryptStream(
            InputStream in,
            OutputStream out,
            byte[] key,
            byte[] nonce,
            byte[] aad,
            long totalInputSize,
            ProgressListener listener
    ) throws Exception {
        SecretKey secretKey = new SecretKeySpec(key, "AES");
        GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH_BITS, nonce);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, spec);

        if (aad != null && aad.length > 0) {
            cipher.updateAAD(aad);
        }

        byte[] inBuffer = new byte[BUFFER_SIZE];
        long processedBytes = 0;
        int bytesRead;

        while ((bytesRead = in.read(inBuffer)) != -1) {
            byte[] cipherChunk = cipher.update(inBuffer, 0, bytesRead);
            if (cipherChunk != null && cipherChunk.length > 0) {
                out.write(cipherChunk);
            }
            processedBytes += bytesRead;
            if (listener != null && totalInputSize > 0) {
                int percent = (int) Math.min(90, (processedBytes * 100) / totalInputSize);
                listener.onProgress(percent, 100, String.format("Encrypting stream: %,d / %,d bytes", processedBytes, totalInputSize));
            }
        }

        byte[] finalChunk = cipher.doFinal();
        if (finalChunk != null && finalChunk.length > 0) {
            out.write(finalChunk);
        }
        out.flush();
    }

    /**
     * Decrypts an input stream (ciphertext + GCM tag) to an output stream in 64KB chunks.
     */
    public static void decryptStream(
            InputStream in,
            OutputStream out,
            byte[] key,
            byte[] nonce,
            byte[] aad,
            long totalCiphertextSize,
            ProgressListener listener
    ) throws Exception {
        SecretKey secretKey = new SecretKeySpec(key, "AES");
        GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH_BITS, nonce);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, secretKey, spec);

        if (aad != null && aad.length > 0) {
            cipher.updateAAD(aad);
        }

        byte[] buffer = new byte[BUFFER_SIZE];
        long processedBytes = 0;
        int bytesRead;

        // Since GCM needs tag at the end, cipher.update streams intermediate plaintext,
        // and doFinal authenticates the tag.
        while ((bytesRead = in.read(buffer)) != -1) {
            byte[] plainChunk = cipher.update(buffer, 0, bytesRead);
            if (plainChunk != null && plainChunk.length > 0) {
                out.write(plainChunk);
            }
            processedBytes += bytesRead;
            if (listener != null && totalCiphertextSize > 0) {
                int percent = (int) Math.min(90, (processedBytes * 100) / totalCiphertextSize);
                listener.onProgress(percent, 100, String.format("Decrypting stream: %,d / %,d bytes", processedBytes, totalCiphertextSize));
            }
        }

        byte[] finalChunk = cipher.doFinal(); // Authenticates tag and flushes final block
        if (finalChunk != null && finalChunk.length > 0) {
            out.write(finalChunk);
        }
        out.flush();
    }
}
