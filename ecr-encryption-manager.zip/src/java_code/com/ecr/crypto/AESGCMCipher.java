package com.ecr.crypto;

import javax.crypto.Cipher;
import javax.crypto.AEADBadTagException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;

/**
 * Encapsulates AES-256-GCM authenticated encryption and decryption.
 * Uses 128-bit authentication tag for integrity and tamper detection.
 */
public final class AESGCMCipher {

    public static final String ALGORITHM = "AES/GCM/NoPadding";
    public static final int GCM_TAG_LENGTH_BITS = 128; // 16 bytes

    private AESGCMCipher() {
        // Utility class
    }

    /**
     * Encrypts plaintext using AES-256-GCM.
     *
     * @param plaintext raw payload bytes
     * @param key       derived 256-bit symmetric key
     * @param nonce     12-byte random IV
     * @param aad       additional authenticated data (header & metadata)
     * @return ciphertext including appended 16-byte GCM authentication tag
     * @throws GeneralSecurityException if encryption fails
     */
    public static byte[] encrypt(byte[] plaintext, byte[] key, byte[] nonce, byte[] aad) throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        SecretKey secretKey = new SecretKeySpec(key, "AES");
        GCMParameterSpec parameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH_BITS, nonce);

        cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);
        if (aad != null && aad.length > 0) {
            cipher.updateAAD(aad);
        }

        return cipher.doFinal(plaintext);
    }

    /**
     * Decrypts AES-256-GCM ciphertext and validates authentication tag.
     *
     * @param ciphertext encrypted bytes including authentication tag
     * @param key        derived 256-bit key
     * @param nonce      12-byte IV
     * @param aad        additional authenticated data (header & metadata)
     * @return original plaintext bytes
     * @throws AEADBadTagException      if password is wrong or ciphertext/metadata was tampered with
     * @throws GeneralSecurityException on general cryptographic errors
     */
    public static byte[] decrypt(byte[] ciphertext, byte[] key, byte[] nonce, byte[] aad) throws GeneralSecurityException {
        try {
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            SecretKey secretKey = new SecretKeySpec(key, "AES");
            GCMParameterSpec parameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH_BITS, nonce);

            cipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec);
            if (aad != null && aad.length > 0) {
                cipher.updateAAD(aad);
            }

            return cipher.doFinal(ciphertext);
        } catch (AEADBadTagException e) {
            throw new AEADBadTagException("Authentication tag validation failed. Password incorrect or file tampered with.");
        }
    }
}
