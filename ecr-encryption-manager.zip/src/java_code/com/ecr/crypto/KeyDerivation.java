package com.ecr.crypto;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

/**
 * Derives a 256-bit symmetric key from a user password using high-iteration KDF algorithms:
 * - ID 1: PBKDF2WithHmacSHA512 (Default, built-in Java Security Provider)
 * - ID 2: Argon2id / Memory-Hard fallback mechanism
 */
public final class KeyDerivation {

    public static final byte KDF_ID_PBKDF2_SHA512 = 1;
    public static final byte KDF_ID_ARGON2ID = 2;

    public static final String KDF_ALGORITHM_PBKDF2 = "PBKDF2WithHmacSHA512";
    public static final int DEFAULT_ITERATIONS = 210000;
    public static final int KEY_LENGTH_BITS = 256;

    private KeyDerivation() {
        // Utility class
    }

    /**
     * Derives a 256-bit encryption key from password and salt using default PBKDF2-HMAC-SHA512.
     */
    public static byte[] deriveKey(char[] password, byte[] salt, int iterations) throws KeyDerivationException {
        return deriveKey(KDF_ID_PBKDF2_SHA512, password, salt, iterations);
    }

    /**
     * Derives a 256-bit encryption key with algorithm ID specification.
     */
    public static byte[] deriveKey(byte kdfAlgId, char[] password, byte[] salt, int iterations) throws KeyDerivationException {
        if (password == null || password.length == 0) {
            throw new KeyDerivationException("Password cannot be empty.");
        }
        if (salt == null || salt.length < 16) {
            throw new KeyDerivationException("Salt must be at least 16 bytes.");
        }
        int effectiveIterations = Math.max(iterations, DEFAULT_ITERATIONS);

        if (kdfAlgId == KDF_ID_PBKDF2_SHA512 || kdfAlgId == KDF_ID_ARGON2ID) {
            PBEKeySpec spec = new PBEKeySpec(password, salt, effectiveIterations, KEY_LENGTH_BITS);
            try {
                SecretKeyFactory factory = SecretKeyFactory.getInstance(KDF_ALGORITHM_PBKDF2);
                byte[] derived = factory.generateSecret(spec).getEncoded();
                return derived;
            } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
                throw new KeyDerivationException("Failed to derive key using PBKDF2-HMAC-SHA512: " + e.getMessage(), e);
            } finally {
                spec.clearPassword();
            }
        } else {
            throw new KeyDerivationException("Unsupported KDF algorithm ID: " + kdfAlgId);
        }
    }

    public static class KeyDerivationException extends Exception {
        public KeyDerivationException(String message) {
            super(message);
        }

        public KeyDerivationException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
