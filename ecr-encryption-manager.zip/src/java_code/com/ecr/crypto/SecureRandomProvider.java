package com.ecr.crypto;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * Provides cryptographically strong pseudo-random number generators (CSPRNG)
 * for generating 256-bit salts and 96-bit nonces (IVs).
 */
public final class SecureRandomProvider {

    private static final SecureRandom SECURE_RANDOM;

    static {
        SecureRandom sr;
        try {
            sr = SecureRandom.getInstanceStrong();
        } catch (NoSuchAlgorithmException e) {
            sr = new SecureRandom();
        }
        SECURE_RANDOM = sr;
    }

    private SecureRandomProvider() {
        // Utility class
    }

    /**
     * Generates a random byte array of the specified length.
     *
     * @param length number of random bytes
     * @return newly generated random byte array
     */
    public static byte[] generateRandomBytes(int length) {
        if (length <= 0) {
            throw new IllegalArgumentException("Random byte length must be positive.");
        }
        byte[] bytes = new byte[length];
        SECURE_RANDOM.nextBytes(bytes);
        return bytes;
    }

    /**
     * Generates a 256-bit (32-byte) cryptographic salt.
     */
    public static byte[] generateSalt() {
        return generateRandomBytes(32);
    }

    /**
     * Generates a 96-bit (12-byte) initialization vector (nonce) for AES-GCM.
     */
    public static byte[] generateNonce() {
        return generateRandomBytes(12);
    }
}
