package com.ecr.crypto;

import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * Provides optional Digital Signature creation and verification for ECR files
 * using standard Java Cryptography (Ed25519 or ECDSA with SHA-256).
 */
public final class DigitalSignature {

    public static final String ALGORITHM = "Ed25519"; // Standard in Java 15+

    private DigitalSignature() {
        // Utility
    }

    public record KeyPairContainer(String publicKeyBase64, String privateKeyBase64) {}

    /**
     * Generates a new Ed25519 key pair for signing and verifying ECR files.
     */
    public static KeyPairContainer generateKeyPair() throws NoSuchAlgorithmException {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance(ALGORITHM);
        KeyPair kp = kpg.generateKeyPair();

        String pub = Base64.getEncoder().encodeToString(kp.getPublic().getEncoded());
        String priv = Base64.getEncoder().encodeToString(kp.getPrivate().getEncoded());

        return new KeyPairContainer(pub, priv);
    }

    /**
     * Digitally signs data using a private key in Base64 format.
     */
    public static byte[] sign(byte[] data, String privateKeyBase64) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(privateKeyBase64);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance(ALGORITHM);
        PrivateKey privateKey = kf.generatePrivate(keySpec);

        Signature signer = Signature.getInstance(ALGORITHM);
        signer.initSign(privateKey);
        signer.update(data);
        return signer.sign();
    }

    /**
     * Verifies a digital signature against data using a public key in Base64 format.
     */
    public static boolean verify(byte[] data, byte[] signatureBytes, String publicKeyBase64) {
        if (data == null || signatureBytes == null || publicKeyBase64 == null || publicKeyBase64.isBlank()) {
            return false;
        }
        try {
            byte[] keyBytes = Base64.getDecoder().decode(publicKeyBase64);
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
            KeyFactory kf = KeyFactory.getInstance(ALGORITHM);
            PublicKey publicKey = kf.generatePublic(keySpec);

            Signature verifier = Signature.getInstance(ALGORITHM);
            verifier.initVerify(publicKey);
            verifier.update(data);
            return verifier.verify(signatureBytes);
        } catch (Exception e) {
            return false;
        }
    }
}
