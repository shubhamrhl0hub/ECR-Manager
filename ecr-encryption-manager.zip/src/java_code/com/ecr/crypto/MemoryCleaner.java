package com.ecr.crypto;

import java.util.Arrays;

/**
 * Utility for scrubbing sensitive cryptographic data from memory.
 * Ensures password char arrays and key byte arrays are zeroed out as soon as they are no longer needed.
 */
public final class MemoryCleaner {

    private MemoryCleaner() {
        // Private constructor to prevent instantiation
    }

    /**
     * Overwrites a character array with zero characters.
     *
     * @param chars the array to clear
     */
    public static void clear(char[] chars) {
        if (chars != null) {
            Arrays.fill(chars, '\0');
        }
    }

    /**
     * Overwrites a byte array with zero bytes.
     *
     * @param bytes the array to clear
     */
    public static void clear(byte[] bytes) {
        if (bytes != null) {
            Arrays.fill(bytes, (byte) 0);
        }
    }
}
