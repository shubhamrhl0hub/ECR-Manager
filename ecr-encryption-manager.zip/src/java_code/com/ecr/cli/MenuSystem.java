package com.ecr.cli;

/**
 * Renders CUI interactive menu options and ASCII headers for ECR Encryption Manager v2.1.
 */
public final class MenuSystem {

    private MenuSystem() {
        // Utility
    }

    public static void printBanner() {
        System.out.println(AnsiConsole.cyan("""
                ┌─────────────────────────────────────────────────────────────┐
                │   ECR HIGH SECURITY TERMINAL ENCRYPTION MANAGER v2.1         │
                │   Java 26 Authenticated AES-256-GCM / PBKDF2 / Ed25519       │
                │   Developer: $HUBHAM                                        │
                └─────────────────────────────────────────────────────────────┘
                """));
    }

    public static void printMainMenu() {
        System.out.println(AnsiConsole.bold("MAIN MENU OPTIONS:"));
        System.out.println("  " + AnsiConsole.green("1.") + " Create Encrypted File (.zip -> .ecr)");
        System.out.println("  " + AnsiConsole.green("2.") + " Decrypt Encrypted File (.ecr -> .zip)");
        System.out.println("  " + AnsiConsole.green("3.") + " Verify Encrypted File Header & Integrity");
        System.out.println("  " + AnsiConsole.green("4.") + " Display File Information & Cryptographic Metadata");
        System.out.println("  " + AnsiConsole.green("5.") + " View Secure Configuration & Audit Log");
        System.out.println("  " + AnsiConsole.green("6.") + " Security Specification & Help");
        System.out.println("  " + AnsiConsole.green("7.") + " Exit");
        System.out.println();
    }
}
