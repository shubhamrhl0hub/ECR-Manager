package com.ecr.cli;

import com.ecr.config.SecureConfigManager;
import com.ecr.crypto.DigitalSignature;
import com.ecr.format.ECRFileHandler;
import com.ecr.format.ECRHeader;
import com.ecr.format.ECRMetadata;
import com.ecr.manager.ECREncryptionManager;
import com.ecr.manager.ProgressListener;
import com.ecr.security.SecurityAudit;
import com.ecr.security.Zeroization;
import com.ecr.util.ByteUtils;

import java.io.Console;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.List;
import java.util.Scanner;

/**
 * Handles terminal command executions for encryption, decryption, verification, digital signatures,
 * secure configuration inspection, and security audit log review.
 */
public class CommandHandler {

    private final ECREncryptionManager manager = new ECREncryptionManager();
    private final Scanner scanner = new Scanner(System.in);

    public void handleEncrypt() {
        System.out.println(AnsiConsole.bold("\n--- 1. ENCRYPT (.zip -> .ecr) ---"));
        System.out.print("Enter source .zip file path: ");
        String srcPathStr = scanner.nextLine().trim();

        if (srcPathStr.isEmpty()) {
            System.out.println(AnsiConsole.red("Error: File path cannot be empty."));
            return;
        }

        Path srcPath = Paths.get(srcPathStr);
        String defaultFileName = srcPath.getFileName() != null ? srcPath.getFileName().toString().replaceAll("(?i)\\.zip$", "") + ".ecr" : "encrypted.ecr";
        Path defaultOutPath = srcPath.getParent() != null ? srcPath.getParent().resolve(defaultFileName) : Paths.get(defaultFileName);
        
        System.out.print("Enter output .ecr file path [" + defaultOutPath.toString() + "]: ");
        String outPathStr = scanner.nextLine().trim();
        Path targetOutPath = outPathStr.isEmpty() ? defaultOutPath : Paths.get(outPathStr);
        if (Files.isDirectory(targetOutPath)) {
            targetOutPath = targetOutPath.resolve(defaultFileName);
        }

        char[] password = readPassword("Enter encryption password: ");
        if (password == null || password.length == 0) {
            System.out.println(AnsiConsole.red("Error: Password cannot be empty."));
            return;
        }

        com.ecr.validation.PasswordValidator.PasswordRating rating = com.ecr.validation.PasswordValidator.evaluate(password);
        if (rating.level() == com.ecr.validation.PasswordValidator.StrengthLevel.WEAK) {
            System.out.println(AnsiConsole.yellow("⚠ Password Rating: WEAK (Score: " + rating.score() + "/100) - " + rating.feedback()));
        } else if (rating.level() == com.ecr.validation.PasswordValidator.StrengthLevel.MEDIUM) {
            System.out.println(AnsiConsole.cyan("ℹ Password Rating: MEDIUM (Score: " + rating.score() + "/100)"));
        } else {
            System.out.println(AnsiConsole.green("✔ Password Rating: " + rating.level() + " (Score: " + rating.score() + "/100)"));
        }

        char[] confirmPass = readPassword("Confirm encryption password: ");
        if (!java.util.Arrays.equals(password, confirmPass)) {
            System.out.println(AnsiConsole.red("Error: Passwords do not match. Encryption aborted."));
            Zeroization.wipe(password);
            Zeroization.wipe(confirmPass);
            return;
        }
        Zeroization.wipe(confirmPass);

        System.out.print("Enable Ed25519 Digital Signature? (y/N): ");
        String signChoice = scanner.nextLine().trim().toLowerCase();
        
        String privKey = null;
        String pubKey = null;

        if (signChoice.equals("y") || signChoice.equals("yes")) {
            try {
                System.out.println(AnsiConsole.cyan("Generating temporary Ed25519 Key Pair for digital signing..."));
                DigitalSignature.KeyPairContainer kp = DigitalSignature.generateKeyPair();
                privKey = kp.privateKeyBase64();
                pubKey = kp.publicKeyBase64();
                System.out.println(AnsiConsole.green("✔ Ed25519 Keypair generated."));
                System.out.println("  Signer Public Key: " + pubKey.substring(0, Math.min(24, pubKey.length())) + "...");
            } catch (Exception e) {
                System.out.println(AnsiConsole.yellow("Warning: Could not generate digital signature keypair: " + e.getMessage()));
            }
        }

        try {
            manager.encryptZipToEcrSigned(srcPath, targetOutPath, password, privKey, pubKey, new ConsoleProgressListener());
        } catch (Exception e) {
            System.out.println(AnsiConsole.red("Encryption failed: " + e.getMessage()));
        }
    }

    public void handleDecrypt() {
        System.out.println(AnsiConsole.bold("\n--- 2. DECRYPT (.ecr -> .zip) ---"));
        System.out.print("Enter source .ecr file path: ");
        String srcPathStr = scanner.nextLine().trim();

        if (srcPathStr.isEmpty()) {
            System.out.println(AnsiConsole.red("Error: File path cannot be empty."));
            return;
        }

        Path srcPath = Paths.get(srcPathStr);
        String defaultFileName = srcPath.getFileName() != null ? srcPath.getFileName().toString().replaceAll("(?i)\\.ecr$", "") + "_decrypted.zip" : "decrypted.zip";
        Path defaultOutPath = srcPath.getParent() != null ? srcPath.getParent().resolve(defaultFileName) : Paths.get(defaultFileName);

        System.out.print("Enter output .zip file path [" + defaultOutPath.toString() + "]: ");
        String outPathStr = scanner.nextLine().trim();
        Path targetOutPath = outPathStr.isEmpty() ? defaultOutPath : Paths.get(outPathStr);
        if (Files.isDirectory(targetOutPath)) {
            targetOutPath = targetOutPath.resolve(defaultFileName);
        }

        char[] password = readPassword("Enter decryption password: ");

        try {
            manager.decryptEcrToZip(srcPath, targetOutPath, password, new ConsoleProgressListener());
        } catch (Exception e) {
            System.out.println(AnsiConsole.red("«Invalid, corrupted, tampered, or unsupported ECR file.»"));
        }
    }

    public void handleVerify() {
        System.out.println(AnsiConsole.bold("\n--- 3. VERIFY ECR FILE INTEGRITY ---"));
        System.out.print("Enter .ecr file path to verify: ");
        String pathStr = scanner.nextLine().trim();

        try {
            boolean valid = manager.verifyEcrFile(Paths.get(pathStr));
            if (valid) {
                System.out.println(AnsiConsole.green("✔ Header Signature & Format Validation: PASSED"));
                System.out.println(AnsiConsole.cyan("File is a valid ECR v1/v2 container."));
            }
        } catch (Exception e) {
            System.out.println(AnsiConsole.red("«Invalid, corrupted, tampered, or unsupported ECR file.»"));
        }
    }

    public void handleInfo() {
        System.out.println(AnsiConsole.bold("\n--- 4. DISPLAY FILE INFORMATION ---"));
        System.out.print("Enter .ecr file path: ");
        String pathStr = scanner.nextLine().trim();

        try {
            ECRFileHandler.ECRContainer container = ECRFileHandler.readEcrFile(Paths.get(pathStr));
            ECRHeader h = container.header();
            ECRMetadata m = container.metadata();

            System.out.println("\n" + AnsiConsole.bold("=== ECR CONTAINER METADATA ==="));
            System.out.println("Magic Signature   : " + new String(h.magic()) + " (0x45 0x43 0x52 0x31)");
            System.out.println("Format Version    : " + h.version());
            System.out.println("KDF Algorithm     : PBKDF2WithHmacSHA512");
            System.out.println("KDF Iterations    : " + String.format("%,d", h.kdfIterations()));
            System.out.println("Salt (256-bit)    : " + ByteUtils.bytesToHex(h.salt()));
            System.out.println("Nonce/IV (96-bit) : " + ByteUtils.bytesToHex(h.nonce()));
            System.out.println("Original Filename : " + m.originalFilename());
            System.out.println("Creation Time     : " + Instant.ofEpochSecond(m.creationTimestamp()));
            System.out.println("Original Size     : " + ByteUtils.formatSize(m.uncompressedSize()));
            System.out.println("SHA-256 Checksum  : " + m.sha256Checksum());
            System.out.println("Digital Signed    : " + (m.hasDigitalSignature() ? "Yes (Ed25519)" : "No"));
            if (m.hasDigitalSignature()) {
                System.out.println("Signer Public Key : " + m.signerPublicKey());
            }
            System.out.println("Ciphertext Bytes  : " + ByteUtils.formatSize(container.ciphertext().length));
            System.out.println(AnsiConsole.green("Status            : Container Structure Valid"));
        } catch (Exception e) {
            System.out.println(AnsiConsole.red("«Invalid, corrupted, tampered, or unsupported ECR file.»"));
        }
    }

    public void handleConfigAndAuditLogs() {
        System.out.println(AnsiConsole.bold("\n--- 5. SECURE CONFIGURATION & AUDIT LOG ---"));
        SecureConfigManager.ConfigSnapshot cfg = SecureConfigManager.getInstance().getConfig();

        System.out.println(AnsiConsole.bold("ACTIVE CONFIGURATION SNAPSHOT:"));
        System.out.println("  Chunk Buffer Size  : " + (cfg.chunkSizeBytes() / 1024) + " KB (" + cfg.chunkSizeBytes() + " bytes)");
        System.out.println("  PBKDF2 Iterations  : " + String.format("%,d", cfg.kdfIterations()));
        System.out.println("  Digital Signatures : " + (cfg.enableDigitalSignatures() ? "Enabled (Ed25519)" : "Disabled"));
        System.out.println("  Progress Display   : " + (cfg.showProgress() ? "Enabled" : "Disabled"));
        System.out.println("  Audit Log File     : " + cfg.auditLogFilePath());
        System.out.println("  Max Log File Size  : " + cfg.maxLogSizeMB() + " MB (Rotation limit)");
        System.out.println("  Max Log Backups    : " + cfg.maxLogFiles() + " files");

        System.out.println("\n" + AnsiConsole.bold("RECENT AUDIT LOG ENTRIES:"));
        List<String> logs = SecurityAudit.getRecentLogs();
        if (logs.isEmpty()) {
            System.out.println("  (No audit log entries recorded yet)");
        } else {
            int start = Math.max(0, logs.size() - 15);
            for (int i = start; i < logs.size(); i++) {
                System.out.println("  " + logs.get(i));
            }
        }
        System.out.println();
    }

    public void handleHelp() {
        System.out.println(AnsiConsole.bold("\n=== SECURITY SPECIFICATION & HELP ==="));
        System.out.println("""
                1. CIPHER ALGORITHM: AES-256-GCM (Galois/Counter Mode) authenticated encryption.
                   - Ensures both confidentiality and data origin authenticity.
                   - 128-bit authentication tag detects any single-bit tampering.
                   
                2. KEY DERIVATION: PBKDF2 with HMAC-SHA512.
                   - High cost factor (210,000 iterations) protects against brute-force attacks.
                   - 256-bit unique random salt per file prevents rainbow table attacks.
                   
                3. STREAMING & LARGE FILE SUPPORT:
                   - 64KB chunked I/O streaming prevents RAM exhaustion on multi-GB archives.
                   
                4. OPTIONAL DIGITAL SIGNATURE:
                   - Ed25519 digital signature support verifies data origin & non-repudiation.
                   
                5. SECURE CONFIGURATION & AUDIT LOG:
                   - Validated settings, fallback default handling, sanitized persistent audit log rotation.
                   
                6. MEMORY SECURITY:
                   - All sensitive password char arrays and byte buffers are explicitly zeroed out.

                7. DEVELOPER INFORMATION:
                   - Developer: $HUBHAM
                """);
    }

    private char[] readPassword(String prompt) {
        Console console = System.console();
        if (console != null) {
            return console.readPassword(prompt);
        } else {
            System.out.print(prompt);
            return scanner.nextLine().toCharArray();
        }
    }

    private static class ConsoleProgressListener implements ProgressListener {
        @Override
        public void onProgress(long bytesProcessed, long totalBytes, String stage) {
            System.out.printf("[%d%%] %s%n", bytesProcessed, stage);
        }

        @Override
        public void onComplete(String message) {
            System.out.println(AnsiConsole.green("✔ " + message));
        }

        @Override
        public void onError(String errorMessage) {
            System.out.println(AnsiConsole.red("✖ " + errorMessage));
        }
    }
}
