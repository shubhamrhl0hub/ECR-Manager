package com.ecr.cli;

import java.util.Scanner;

/**
 * Terminal CUI interactive loop controller for ECR Encryption Manager v2.1.
 */
public class TerminalInterface {

    private final CommandHandler commandHandler = new CommandHandler();
    private final Scanner scanner = new Scanner(System.in);

    public void start() {
        MenuSystem.printBanner();

        boolean running = true;
        while (running) {
            MenuSystem.printMainMenu();
            System.out.print(AnsiConsole.bold("Enter option (1-7): "));
            String input = scanner.nextLine().trim();

            switch (input) {
                case "1" -> commandHandler.handleEncrypt();
                case "2" -> commandHandler.handleDecrypt();
                case "3" -> commandHandler.handleVerify();
                case "4" -> commandHandler.handleInfo();
                case "5" -> commandHandler.handleConfigAndAuditLogs();
                case "6" -> commandHandler.handleHelp();
                case "7" -> {
                    System.out.println(AnsiConsole.cyan("Exiting ECR Encryption Manager. Stay safe!"));
                    running = false;
                }
                default -> System.out.println(AnsiConsole.red("Invalid option. Please enter a number between 1 and 7.\n"));
            }
        }
    }
}
