package com.ecr.validation;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Ensures files exist, are readable, and conform to expected file extensions and magic headers.
 */
public final class FileFormatValidator {

    private static final byte[] ZIP_MAGIC = new byte[]{(byte) 0x50, (byte) 0x4B, (byte) 0x03, (byte) 0x04};

    private FileFormatValidator() {
        // Utility
    }

    public static void validateInputFile(Path file) throws IOException {
        if (!Files.exists(file)) {
            throw new IOException("File does not exist: " + file);
        }
        if (!Files.isRegularFile(file)) {
            throw new IOException("Not a regular file: " + file);
        }
        if (!Files.isReadable(file)) {
            throw new IOException("Permission denied reading file: " + file);
        }
        if (Files.size(file) == 0) {
            throw new IOException("File is empty.");
        }
    }

    public static boolean isZipFile(Path file) {
        try (InputStream is = Files.newInputStream(file)) {
            byte[] header = new byte[4];
            int read = is.read(header);
            if (read < 4) return false;
            return header[0] == ZIP_MAGIC[0] &&
                   header[1] == ZIP_MAGIC[1] &&
                   header[2] == ZIP_MAGIC[2] &&
                   header[3] == ZIP_MAGIC[3];
        } catch (IOException e) {
            return false;
        }
    }
}
