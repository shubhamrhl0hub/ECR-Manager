package com.ecr.validation;

import com.ecr.format.ECRHeader;
import com.ecr.format.ECRFileStructure;
import com.ecr.security.ConstantTime;

/**
 * Validates file headers for magic bytes, format version, and parameter boundaries.
 */
public final class HeaderValidator {

    private HeaderValidator() {
        // Utility
    }

    public static void validateHeader(ECRHeader header) throws ValidationException {
        if (header == null) {
            throw new ValidationException("Invalid, corrupted, tampered, or unsupported ECR file.");
        }

        if (!ConstantTime.equals(header.magic(), ECRFileStructure.MAGIC_HEADER)) {
            throw new ValidationException("Invalid, corrupted, tampered, or unsupported ECR file.");
        }

        if (header.version() != ECRFileStructure.CURRENT_VERSION) {
            throw new ValidationException("Invalid, corrupted, tampered, or unsupported ECR file.");
        }

        if (header.salt() == null || header.salt().length != 32) {
            throw new ValidationException("Invalid, corrupted, tampered, or unsupported ECR file.");
        }

        if (header.nonce() == null || header.nonce().length != 12) {
            throw new ValidationException("Invalid, corrupted, tampered, or unsupported ECR file.");
        }

        if (header.kdfIterations() < 10000) {
            throw new ValidationException("Invalid, corrupted, tampered, or unsupported ECR file.");
        }
    }

    public static class ValidationException extends Exception {
        public ValidationException(String message) {
            super(message);
        }
    }
}
