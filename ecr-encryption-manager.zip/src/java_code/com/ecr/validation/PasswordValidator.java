package com.ecr.validation;

/**
 * Validates password quality, measures entropy, and provides strength feedback.
 */
public final class PasswordValidator {

    public enum StrengthLevel {
        WEAK,
        MEDIUM,
        STRONG,
        VERY_STRONG
    }

    public record PasswordRating(StrengthLevel level, int score, String feedback) {}

    private PasswordValidator() {
        // Utility
    }

    public static PasswordRating evaluate(char[] password) {
        if (password == null || password.length == 0) {
            return new PasswordRating(StrengthLevel.WEAK, 0, "Password cannot be empty.");
        }

        int length = password.length;
        boolean hasUpper = false;
        boolean hasLower = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (char c : password) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isLowerCase(c)) hasLower = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else hasSpecial = true;
        }

        int score = length * 5;
        if (hasUpper) score += 10;
        if (hasLower) score += 10;
        if (hasDigit) score += 15;
        if (hasSpecial) score += 20;

        score = Math.min(score, 100);

        StrengthLevel level;
        String feedback;

        if (length < 8 || score < 40) {
            level = StrengthLevel.WEAK;
            feedback = "Weak password. Recommend at least 8 characters with numbers & symbols.";
        } else if (score < 65) {
            level = StrengthLevel.MEDIUM;
            feedback = "Moderate password strength. Adding special symbols will improve key security.";
        } else if (score < 85) {
            level = StrengthLevel.STRONG;
            feedback = "Strong password. Good entropy for cryptographic key derivation.";
        } else {
            level = StrengthLevel.VERY_STRONG;
            feedback = "Very Strong password. Outstanding entropy resistance against offline attack.";
        }

        return new PasswordRating(level, score, feedback);
    }
}
