package com.ecr.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * File utility operations.
 */
public final class FileUtils {

    private FileUtils() {
        // Utility
    }

    public static boolean confirmOverwrite(Path path) {
        if (Files.exists(path)) {
            System.out.printf("File '%s' already exists. Overwrite? (y/N): ", path.getFileName());
            return true;
        }
        return true;
    }
}
