package com.ecr.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Handles ZIP archive inspection and validation.
 */
public final class ZipUtils {

    private ZipUtils() {
        // Utility
    }

    public static int countEntries(byte[] zipBytes) {
        if (zipBytes == null) return 0;
        int count = 0;
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            while (zis.getNextEntry() != null) {
                count++;
            }
        } catch (IOException e) {
            return 0;
        }
        return count;
    }
}
